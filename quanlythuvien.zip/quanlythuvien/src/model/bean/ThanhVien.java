package model.bean;

public class ThanhVien {
	private String matv;
	private String tentv;
	private String diachi;
	private String maph;
	private String sodt;
	private String email;
	private int xoa;
	private String ngayMuon;
	private String tenSach;
	public ThanhVien() {
	}
	
	public String getNgayMuon() {
		return ngayMuon;
	}

	public void setNgayMuon(String ngayMuon) {
		this.ngayMuon = ngayMuon;
	}

	public String getTenSach() {
		return tenSach;
	}

	public void setTenSach(String tenSach) {
		this.tenSach = tenSach;
	}
public ThanhVien( String tentv, String ngayMuon, String tenSach) {
		
		this.tentv = tentv;
		this.ngayMuon = ngayMuon;
		this.tenSach = tenSach;
	}

	public ThanhVien( String tentv, String diachi, String maph, String sodt, String email, int xoa) {
		
		this.tentv = tentv;
		this.diachi = diachi;
		this.maph = maph;
		this.sodt = sodt;
		this.email = email;
		this.xoa = xoa;
	}
	public ThanhVien(String matv, String tentv, String diachi, String maph, String sodt, String email, int xoa) {
		this.matv = matv;
		this.tentv = tentv;
		this.diachi = diachi;
		this.maph = maph;
		this.sodt = sodt;
		this.email = email;
		this.xoa = xoa;
	}
	public String getMatv() {
		return matv;
	}
	public void setMatv(String matv) {
		this.matv = matv;
	}
	public String getTentv() {
		return tentv;
	}
	public void setTentv(String tentv) {
		this.tentv = tentv;
	}
	public String getDiachi() {
		return diachi;
	}
	public void setDiachi(String diachi) {
		this.diachi = diachi;
	}
	public String getMaph() {
		return maph;
	}
	public void setMaph(String maph) {
		this.maph = maph;
	}
	public String getSodt() {
		return sodt;
	}
	public void setSodt(String sodt) {
		this.sodt = sodt;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getXoa() {
		return xoa;
	}
	public void setXoa(int xoa) {
		this.xoa = xoa;
	}
	
	public String toString() {
		return tentv;
	}
	
}
