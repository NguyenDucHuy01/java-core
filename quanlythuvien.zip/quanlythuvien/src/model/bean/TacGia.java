package model.bean;

public class TacGia {
	private String matg;
	private String tentg;
	public TacGia() {
		
	}
	public TacGia(String matg, String tentg) {
		this.matg = matg;
		this.tentg = tentg;
	}
	
	public TacGia(String tentg) {
		this.tentg = tentg;
	}
	public String getMatg() {
		return matg;
	}
	public void setMatg(String matg) {
		this.matg = matg;
	}
	public String getTentg() {
		return tentg;
	}
	public void setTentg(String tentg) {
		this.tentg = tentg;
	}
	
	@Override
	public String toString() {
		return tentg;
	}

}
