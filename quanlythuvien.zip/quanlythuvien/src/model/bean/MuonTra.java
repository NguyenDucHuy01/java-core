package model.bean;

public class MuonTra {
	private String maGiaoDich;
	private String ngayMuon;
	private String ngayTra;
	private String maTv;
	private int soLuong;
	private int xoa;
	

	public MuonTra(String maGiaoDich, String ngayMuon, String ngayTra, String maTv, int soLuong,
			int xoa) {
		
		this.maGiaoDich = maGiaoDich;
		this.ngayMuon = ngayMuon;
		this.ngayTra = ngayTra;
		this.maTv = maTv;
		this.soLuong = soLuong;
		this.xoa = xoa;
	}
	
	
	
	public MuonTra(String ngayMuon, String ngayTra, String maTv, int soLuong,
			int xoa) {
		this.ngayMuon = ngayMuon;
		this.ngayTra = ngayTra;
		this.maTv = maTv;
		this.soLuong = soLuong;
		this.xoa = xoa;
	}


	public MuonTra() {
		
	}


	public String getMagiaodich() {
		return maGiaoDich;
	}


	public void setMaGiaoDich(String maGiaoDich) {
		this.maGiaoDich = maGiaoDich;
	}


	public String getNgaymuon() {
		return ngayMuon;
	}


	public void setNgaymuon(String ngaymuon) {
		this.ngayMuon = ngaymuon;
	}


	public String getNgaytra() {
		return ngayTra;
	}


	public void setNgaytra(String ngaytra) {
		this.ngayTra = ngaytra;
	}


	public String getMatv() {
		return maTv;
	}


	public void setMatv(String matv) {
		this.maTv = matv;
	}


	public int getSoluong() {
		return soLuong;
	}


	public void setSoluong(int soluong) {
		this.soLuong = soluong;
	}


	public int getXoa() {
		return xoa;
	}


	public void setXoa(int xoa) {
		this.xoa = xoa;
	}
	

}
