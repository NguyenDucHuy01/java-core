package model.bean;

public class Sach {
	private String mas;
	private String tens;
	private String matg;
	private String manxb;
	private String namxb;
	private String matls;
	private int soluong;
	private int xoa;
	private int tong;
	private int tonKho;
	
	public Sach() {
		
	}
//	public Sach(String tens,int tong, int tonKho) {
//		this.tens = tens;
//		this.tong = tong;
//		this.tonKho = tonKho;
//	}
	
	public Sach(String mas, String tens, String matg, String manxb, String namxb, String matls, int soluong, int xoa) {
		this.mas = mas;
		this.tens = tens;
		this.matg = matg;
		this.manxb = manxb;
		this.namxb = namxb;
		this.matls = matls;
		this.soluong = soluong;
		this.xoa = xoa;
	}
	
	
	public Sach(String tens, String matg, String manxb, String namxb, String matls, int soluong, int xoa) {
		this.tens = tens;
		this.matg = matg;
		this.manxb = manxb;
		this.namxb = namxb;
		this.matls = matls;
		this.soluong = soluong;
		this.xoa = xoa;
	}
	
	
	
	
	public String getMas() {
		return mas;
	}
	public void setMas(String mas) {
		this.mas = mas;
	}
	public String getTens() {
		return tens;
	}
	public void setTens(String tens) {
		this.tens = tens;
	}
	public String getMatg() {
		return matg;
	}
	public void setMatg(String matg) {
		this.matg = matg;
	}
	public String getManxb() {
		return manxb;
	}
	public void setManxb(String manxb) {
		this.manxb = manxb;
	}
	public String getNamxb() {
		return namxb;
	}
	public void setNamxb(String namxb) {
		this.namxb = namxb;
	}
	public String getMatls() {
		return matls;
	}
	public void setMatls(String matls) {
		this.matls = matls;
	}
	public int getSoluong() {
		return soluong;
	}
	public void setSoluong(int soluong) {
		this.soluong = soluong;
	}
	public int getXoa() {
		return xoa;
	}
	public void setXoa(int xoa) {
		this.xoa = xoa;
	}
	
	public String toString() {
		return tens;
	}
	public int getTong() {
		return tong;
	}
	public void setTong(int tong) {
		this.tong = tong;
	}
	public int getTonKho() {
		return tonKho;
	}
	public void setTonKho(int tonKho) {
		this.tonKho = tonKho;
	}

}
