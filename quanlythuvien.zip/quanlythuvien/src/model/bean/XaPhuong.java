package model.bean;

public class XaPhuong {
	private String maph;
	private String name;
	private String type;
	private String maqh;
	public XaPhuong() {
	}
	public XaPhuong(String maph, String name, String type, String maqh) {
		this.maph = maph;
		this.name = name;
		this.type = type;
		this.maqh = maqh;
	}
	public String getMaph() {
		return maph;
	}
	public void setMaph(String maph) {
		this.maph = maph;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMaqh() {
		return maqh;
	}
	public void setMaqh(String maqh) {
		this.maqh = maqh;
	}
	
	public String toString() {
		return name;
	}
}
