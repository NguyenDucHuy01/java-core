package model.bean;

public class ChiTietMuonTra {
	private String mactpm;
	private String mas;
	private String magiaodich;
	
	
	public ChiTietMuonTra() {
	}

	public ChiTietMuonTra(String mactpm, String mas, String magiaodich) {
		this.mactpm = mactpm;
		this.mas = mas;
		this.magiaodich = magiaodich;
	}
	
	public ChiTietMuonTra(String mas, String magiaodich) {
		this.mas = mas;
		this.magiaodich = magiaodich;
	}

	public String getMactpm() {
		return mactpm;
	}

	public void setMactpm(String mactpm) {
		this.mactpm = mactpm;
	}

	public String getMas() {
		return mas;
	}

	public void setMas(String mas) {
		this.mas = mas;
	}

	public String getMagiaodich() {
		return magiaodich;
	}

	public void setMagiaodich(String magiaodich) {
		this.magiaodich = magiaodich;
	}
	
	

}
