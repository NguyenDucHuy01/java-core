package model.bean;

public class NhaXuatBan {
	private String manxb;
	private String tennxb;
	public NhaXuatBan() {
	}
	public NhaXuatBan(String manxb, String tennxb) {
		this.manxb = manxb;
		this.tennxb = tennxb;
	}
	public String getManxb() {
		return manxb;
	}
	public void setManxb(String manxb) {
		this.manxb = manxb;
	}
	public String getTennxb() {
		return tennxb;
	}
	public void setTennxb(String tennxb) {
		this.tennxb = tennxb;
	}
	
	public String toString() {
		return tennxb;
	}

}
