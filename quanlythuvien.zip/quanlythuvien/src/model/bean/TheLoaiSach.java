package model.bean;

public class TheLoaiSach {
	private String matls;
	private String tentls;
	public TheLoaiSach() {
	}
	public TheLoaiSach(String matls, String tentls) {
		this.matls = matls;
		this.tentls = tentls;
	}
	public String getMatls() {
		return matls;
	}
	public void setMatls(String matls) {
		this.matls = matls;
	}
	public String getTentls() {
		return tentls;
	}
	public void setTentls(String tentls) {
		this.tentls = tentls;
	}
	
	public String toString() {
		return tentls;
	}
	
}
