package model.dao;

import java.util.List;
import model.bean.TacGia;

public interface ITacGiaDao {
	List<TacGia> getAllTacGia();

	List<TacGia> getNameTacGia(String tentg);
	
	TacGia getTacGia(String matg, String tentg);
	
	TacGia getTacGia(String tentg);

	boolean addTacGia(TacGia tacgia);

	boolean updateTacGia(TacGia tacgia);

	boolean deleteTacGia(TacGia tacgia);

}
