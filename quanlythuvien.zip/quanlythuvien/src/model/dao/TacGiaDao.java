package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.database.ConnectionUtil;
import model.bean.TacGia;

public class TacGiaDao implements ITacGiaDao{
	private ConnectionUtil connectionUtil = new ConnectionUtil();
	@Override
	public List<TacGia> getAllTacGia() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM tacgia";
		List<TacGia> listTacGia = new ArrayList<TacGia>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			TacGia tacgia;
			while (result.next()) {
				tacgia = new TacGia(result.getString("matg"), result.getString("tentg"));
				listTacGia.add(tacgia);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listTacGia;
	}

	@Override
	public TacGia getTacGia(String matg, String tentg) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM tacgia WHERE matg = ? and tentg = ?";
		List<TacGia> listTacGia = new ArrayList<TacGia>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, matg);
			statement.setString(2, tentg);

			result = statement.executeQuery();

			TacGia tacgia;
			while (result.next()) {
				tacgia = new TacGia(result.getString("matg"), result.getString("tentg"));
				listTacGia.add(tacgia);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listTacGia.size() == 0 ? null : listTacGia.get(0);
	}

	@Override
	public TacGia getTacGia(String tentg) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM tacgia WHERE tentg = ? ";
		List<TacGia> listTacGia = new ArrayList<TacGia>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(2, tentg);
			result = statement.executeQuery();
			TacGia tacgia;
			while (result.next()) {
				tacgia = new TacGia(result.getString("matg"), result.getString("tentg"));
				listTacGia.add(tacgia);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listTacGia.size() == 0 ? null : listTacGia.get(0);
	}

	@Override
	public boolean addTacGia(TacGia tacgia) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO tacgia VALUES(?, ?)";

		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		int status = 0;
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, tacgia.getMatg());
			statement.setString(2, tacgia.getTentg());
			status = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return status > 0 ? true : false;
	}

	@Override
	public boolean updateTacGia(TacGia tacgia) {
		// TODO Auto-generated method stub
		boolean statusExecute = false;
		String sql = "UPDATE `tacgia` SET `tentg`=? WHERE matg =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, tacgia.getTentg());			
			statement.setString(2, tacgia.getMatg());
			
			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
	}

	@Override
	public boolean deleteTacGia(TacGia tacgia) {
		boolean statusExecute = false;
		String sql = "DELETE FROM `tacgia` WHERE `matg` = ?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, tacgia.getMatg());
			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
	}

	@Override
	public List<TacGia> getNameTacGia(String tentg) {
		String sql = "SELECT * FROM tacgia WHERE tentg LIKE '%" + tentg + "%'";
		List<TacGia> listTacGia = new ArrayList<TacGia>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();
			TacGia tacgia;
			while (result.next()) {
				tacgia = new TacGia(result.getString("matg"), result.getString("tentg"));
				listTacGia.add(tacgia);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listTacGia;
	}

}
