package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.database.ConnectionUtil;
import model.bean.ChiTietMuonTra;




public class ChiTietMuonTraDao implements IChiTietMuonTra {
	private ConnectionUtil connectionUtil = new ConnectionUtil();

	@Override
	public List<ChiTietMuonTra> getAllChiTietMuonTra() {
		String sql = "SELECT * FROM chitietphieumoun";
		 List<ChiTietMuonTra> listChiTietMuonTra = new ArrayList<ChiTietMuonTra>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			ChiTietMuonTra chiTietMuonTra;
			while (result.next()) {
				chiTietMuonTra = new ChiTietMuonTra(result.getString("mactpm"),result.getString("mas"),result.getString("magiaodich"));
				listChiTietMuonTra.add(chiTietMuonTra);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return listChiTietMuonTra;
	}
	public List<ChiTietMuonTra> getMaSachByMaGD(String maGiaoDich) {
		String sql = "SELECT chitietphieumoun.mas FROM chitietphieumoun WHERE chitietphieumoun.magiaodich = ?";
		 List<ChiTietMuonTra> listChiTietMuonTra = new ArrayList<ChiTietMuonTra>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, maGiaoDich);
			result = statement.executeQuery();

			ChiTietMuonTra chiTietMuonTra;
			while (result.next()) {
				chiTietMuonTra = new ChiTietMuonTra();
				chiTietMuonTra.setMas(result.getString("mas"));
				listChiTietMuonTra.add(chiTietMuonTra);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return listChiTietMuonTra;
	}
	@Override
	public ChiTietMuonTra getChiTietMuonTra(String mactpm, String mas) {
		String sql = "SELECT * FROM chitietphieumoun WHERE mactpm = ? and mas = ?";
		 List<ChiTietMuonTra> listChiTietMuonTra = new ArrayList<ChiTietMuonTra>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, mactpm);
			statement.setString(2, mas);
			result = statement.executeQuery();

			ChiTietMuonTra chiTietMuonTra;
			while (result.next()) {
				chiTietMuonTra = new ChiTietMuonTra(result.getString("mactpm"),result.getString("mas"),result.getString("magiaodich"));
				listChiTietMuonTra.add(chiTietMuonTra);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listChiTietMuonTra.size() == 0 ? null : listChiTietMuonTra.get(0);
	}

	@Override
	public ChiTietMuonTra getChiTietMuonTra(String mactpm) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM chitietphieumoun WHERE mactpm = ?";
		 List<ChiTietMuonTra> listChiTietMuonTra = new ArrayList<ChiTietMuonTra>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, mactpm);
			result = statement.executeQuery();

			ChiTietMuonTra chiTietMuonTra;
			while (result.next()) {
				chiTietMuonTra = new ChiTietMuonTra(result.getString("mactpm"),result.getString("mas"),result.getString("magiaodich"));
				listChiTietMuonTra.add(chiTietMuonTra);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listChiTietMuonTra.size() == 0 ? null : listChiTietMuonTra.get(0);
	}

	@Override
	public boolean addChiTietMuonTra(ChiTietMuonTra chiTietMuonTra) {
		String sql = "INSERT INTO chitietphieumoun VALUES(null, ?, ?)";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		int status = 0;
		try {
			statement = connection.prepareStatement(sql);
			
			statement.setString(1, chiTietMuonTra.getMas());
			statement.setString(2, chiTietMuonTra.getMagiaodich());

			status = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return status > 0 ? true : false;
	}

	@Override
	public boolean updateChiTietMuonTra(ChiTietMuonTra chiTietMuonTra) {
		boolean statusExecute = false;
		String sql = "UPDATE `chitietphieumoun` SET `mas`=?,`magiaodich`=? WHERE mactpm =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		
		
		
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, chiTietMuonTra.getMas());
			statement.setString(2, chiTietMuonTra.getMagiaodich());
			statement.setString(3, chiTietMuonTra.getMactpm());

			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
	}

	@Override
	public boolean deleteChiTietMuonTra(ChiTietMuonTra chiTietMuonTra) {
		boolean statusExecute = false;
		String sql = "DELETE FROM `chitietphieumoun` WHERE `mactpm` = ?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, chiTietMuonTra.getMactpm());
			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
	}
	
}
