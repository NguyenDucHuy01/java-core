package model.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import common.database.ConnectionUtil;
import model.bean.Sach;

public class SachDao implements ISachDao {
	private ConnectionUtil connectionUtil = new ConnectionUtil();

	@Override
	public List<Sach> getAllSach() {
		String sql = "SELECT * FROM sach";
		List<Sach> listSach = new ArrayList<Sach>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();
			Sach sach;
			while (result.next()) {
				sach = new Sach(result.getString("mas"), result.getString("tens"), result.getString("matg"),
						result.getString("manxb"), result.getString("namxb"), result.getString("matls"),
						result.getInt("soluong"), result.getInt("xoa"));
				listSach.add(sach);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listSach;
	}

	@Override
	public List<Sach> getNameSach(String tens) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM sach WHERE tens LIKE '%" + tens + "%'";
		List<Sach> listSach = new ArrayList<Sach>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			Sach sach;
			while (result.next()) {
				sach = new Sach(result.getString("mas"), result.getString("tens"), result.getString("matg"),
						result.getString("manxb"), result.getString("namxb"), result.getString("matls"),
						result.getInt("soluong"), result.getInt("xoa"));
				listSach.add(sach);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listSach;
	}


//	public Sach getSach(String tens) {
//		// TODO Auto-generated method stub
//		String sql = "SELECT * FROM sach WHERE tens LIKE '%" + tens + "%'";
//		List<Sach> listSach = new ArrayList<Sach>();
//		Connection connection = connectionUtil.getConnection();
//		PreparedStatement statement = null;
//		ResultSet result = null;
//
//		try {
//			statement = connection.prepareStatement(sql);
//			statement.setString(2, tens);
//			result = statement.executeQuery();
//			Sach sach;
//			while (result.next()) {
//				sach = new Sach(result.getString("mas"), result.getString("tens"), result.getString("matg"),
//						result.getString("manxb"), result.getString("namxb"), result.getString("matls"),
//						result.getInt("soluong"), result.getInt("xoa"));
//				listSach.add(sach);
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			connectionUtil.closeResultSet(result);
//			connectionUtil.closeStatement(statement);
//			connectionUtil.closeConnection(connection);
//		}
//
//		return listSach.size() == 0 ? null : listSach.get(0);
//	}

	@Override
	public boolean addSach(Sach sach) {
		String sql = "INSERT INTO sach VALUES(NULL, ?, ?, ?, ?, ?, ?,?)";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		int status = 0;
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, sach.getTens());
			statement.setString(2, sach.getMatg());
			statement.setString(3, sach.getManxb());
			statement.setDate(4, Date.valueOf(sach.getNamxb()));
			statement.setString(5, sach.getMatls());
			statement.setInt(6, sach.getSoluong());
			statement.setInt(7, sach.getXoa());

			status = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return status > 0 ? true : false;
	}

	@Override
	public boolean updateSach(Sach sach) {
		boolean statusExecute = false;
		String sql = "UPDATE `sach` SET `tens`=?,`matg`=?,`manxb`=?, `namxb`=?,`matls`=?,`soluong`=?, `xoa`=? WHERE mas =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, sach.getTens());
			statement.setString(2, sach.getMatg());
			statement.setString(3, sach.getManxb());
			statement.setDate(4, Date.valueOf(sach.getNamxb()));
			statement.setString(5, sach.getMatls());
			statement.setInt(6, sach.getSoluong());
			statement.setInt(7, 1);			
			statement.setString(8, sach.getMas());

			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return statusExecute;
	}

	@Override
	public boolean deleteSach(Sach sach) {
		// TODO Auto-generated method stub
		boolean statusExecute = false;
		String sql = "UPDATE `sach` SET `tens`=?,`matg`=?,`manxb`=?, `namxb`=?,`matls`=?,`soluong`=?, `xoa`=? WHERE mas =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, sach.getTens());
			statement.setString(2, sach.getMatg());
			statement.setString(3, sach.getManxb());
			statement.setDate(4, Date.valueOf(sach.getNamxb()));
			statement.setString(5, sach.getMatls());
			statement.setInt(6, sach.getSoluong());
			statement.setInt(7, 0);			
			statement.setString(8, sach.getMas());

			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return statusExecute;
	}

	@Override
	public List<Sach> getThongKe() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Sach> getMaSach(String mas) {
		String sql = "SELECT * FROM sach WHERE mas = ?";
		List<Sach> listSach = new ArrayList<Sach>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, mas);
			result = statement.executeQuery();

			Sach sach;
			while (result.next()) {
				sach = new Sach(result.getString("mas"), result.getString("tens"), result.getString("matg"),
						result.getString("manxb"), result.getString("namxb"), result.getString("matls"),
						result.getInt("soluong"), result.getInt("xoa"));
				listSach.add(sach);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listSach;
	}
	
	public boolean updateSach1(Sach sach) {
		boolean statusExecute = false;
		String sql = "UPDATE `sach` SET `tens`=?,`matg`=?,`manxb`=?, `namxb`=?,`matls`=?,`soluong`=?, `xoa`=? WHERE mas =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, sach.getTens());
			statement.setString(2, sach.getMatg());
			statement.setString(3, sach.getManxb());
			statement.setString(4, sach.getNamxb());
			statement.setString(5, sach.getMatls());
			statement.setInt(6, sach.getSoluong());
			statement.setInt(7, 1);			
			statement.setString(8, sach.getMas());

			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return statusExecute;
	}
	public List<Sach> getTenSachByMaMuonTra(String magiaodich) {
		String sql = "SELECT tens FROM muontra "
				+ "JOIN chitietphieumoun ON muontra.magiaodich = chitietphieumoun.magiaodich "
				+ "JOIN sach on chitietphieumoun.mas = sach.mas WHERE muontra.magiaodich  =  ?";
		List<Sach> listTenSach = new ArrayList<Sach>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, magiaodich);
			result = statement.executeQuery();

			Sach sach;
			while (result.next()) {
				sach = new Sach();
				sach.setTens(result.getString("tens"));
				listTenSach.add(sach);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listTenSach;
	}
}
