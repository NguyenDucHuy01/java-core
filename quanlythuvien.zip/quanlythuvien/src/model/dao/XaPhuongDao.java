package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.database.ConnectionUtil;
import model.bean.XaPhuong;

public class XaPhuongDao {
	private ConnectionUtil connectionUtil = new ConnectionUtil();
	public List<XaPhuong> getAllXaPhuong() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM xaphuong";
		List<XaPhuong> listXaPhuong = new ArrayList<XaPhuong>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			XaPhuong xaphuong;
			while (result.next()) {
				//xaphuong = new XaPhuong(result.getString("maph"), result.getString("name"),result.getString("type"),result.getString("maqh"));
				xaphuong = new XaPhuong();
				xaphuong.setMaph(result.getString("maph"));
				xaphuong.setName(result.getString("name"));
				listXaPhuong.add(xaphuong);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listXaPhuong;
	}

}
