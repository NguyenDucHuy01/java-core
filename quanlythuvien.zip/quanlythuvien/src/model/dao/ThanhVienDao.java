package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//import com.mysql.cj.protocol.Resultset;
import common.database.ConnectionUtil;
import model.bean.QuanHuyen;
import model.bean.ThanhVien;
import model.bean.TinhThanhPho;
import model.bean.XaPhuong;

public class ThanhVienDao implements IThanhVienDao {
	
	private ConnectionUtil connectionUtil = new ConnectionUtil();
	
	
	@Override
	public List<TinhThanhPho> getAllTinhThanhPho() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM tinhthanhpho";
		List<TinhThanhPho> listTinhThanhPho = new ArrayList<TinhThanhPho>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			TinhThanhPho tinhthanhpho;
			while (result.next()) {
				//tinhthanhpho = new TinhThanhPho(result.getString("matp"), result.getString("name"),result.getString("type"));
				tinhthanhpho = new TinhThanhPho();
				tinhthanhpho.setMatp(result.getString("matp"));
				tinhthanhpho.setName(result.getString("name"));
				listTinhThanhPho.add(tinhthanhpho);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listTinhThanhPho;
	}

	@Override
	public List<QuanHuyen> getAllQuanHuyen() {
	
		String sql = "SELECT * FROM quanhuyen";
		List<QuanHuyen> listQuanHuyen = new ArrayList<QuanHuyen>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			QuanHuyen quanhuyen;
			while (result.next()) {
				//quanhuyen = new QuanHuyen(result.getString("maqh"), result.getString("name"),result.getString("type"),result.getString("matp"));
				quanhuyen = new QuanHuyen();
				quanhuyen.setName(result.getString("name"));
				quanhuyen.setMaqh(result.getString("maqh"));
				listQuanHuyen.add(quanhuyen);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listQuanHuyen;
	}

	public List<QuanHuyen> getAllQuanHuyenByThanhPho(String maThanhPho) {
		String sql = "SELECT * FROM quanhuyen where matp = ?";
		List<QuanHuyen> listQuanHuyen = new ArrayList<QuanHuyen>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, maThanhPho);
			result = statement.executeQuery();

			QuanHuyen quanhuyen;
			while (result.next()) {
				quanhuyen = new QuanHuyen();
				quanhuyen.setName(result.getString("name"));
				quanhuyen.setMaqh(result.getString("maqh"));
				listQuanHuyen.add(quanhuyen);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listQuanHuyen;
	}
	
	@Override
	public List<XaPhuong> getAllXaPhuong() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM xaphuong";
		List<XaPhuong> listXaPhuong = new ArrayList<XaPhuong>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			XaPhuong xaphuong;
			while (result.next()) {
				xaphuong = new XaPhuong();
				xaphuong.setMaph(result.getString("maph"));
				xaphuong.setName(result.getString("name"));
				xaphuong.setMaqh(result.getString("maqh"));
				listXaPhuong.add(xaphuong);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listXaPhuong;
	}
	@Override
	public List<ThanhVien> getAllThanhVien() {
		String sql = "SELECT * FROM thanhvien ";
		List<ThanhVien> listThanhVien = new ArrayList<ThanhVien>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			ThanhVien thanhvien;
			while (result.next()) {
				thanhvien = new ThanhVien(result.getString("matv"), result.getString("tentv"),result.getString("diachi"),result.getString("maph"),result.getString("sodt"),result.getString("email"), result.getInt("xoa"));
				listThanhVien.add(thanhvien);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listThanhVien;
	}

	@Override
	public List<ThanhVien> getNameThanhVien(String tentv) {
		String sql = "SELECT * FROM thanhvien WHERE tentv LIKE '%"  + tentv + "%'";
		List<ThanhVien> listThanhVien = new ArrayList<ThanhVien>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			ThanhVien thanhvien;
			while (result.next()) {
				thanhvien = new ThanhVien(result.getString("matv"), result.getString("tentv"),result.getString("diachi"),result.getString("maph"),result.getString("sodt"),result.getString("email"), result.getInt("xoa"));
				listThanhVien.add(thanhvien);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listThanhVien;
	}

	@Override
	public ThanhVien getThanhVien(String tentv) {
		
		String sql = "SELECT * FROM thanhvien WHERE tentv = ? ";
		List<ThanhVien> listThanhVien = new ArrayList<ThanhVien>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, tentv);
			result = statement.executeQuery();
			ThanhVien thanhvien1;
			while (result.next()) {
				thanhvien1 = new ThanhVien();
				thanhvien1.setTentv(result.getString("tentv"));
				listThanhVien.add(thanhvien1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listThanhVien.size() == 0 ? null : listThanhVien.get(0);
	}

	@Override
	public boolean addThanhVien(ThanhVien thanhvien) {
		String sql = "INSERT INTO thanhvien VALUES(?, ?, ?, ?, ?, ?, ?)";

		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		int status = 0;
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, thanhvien.getMatv());
			statement.setString(2, thanhvien.getTentv());
			statement.setString(3, thanhvien.getDiachi());
			statement.setString(4, thanhvien.getMaph());
			statement.setString(5, thanhvien.getSodt());
			statement.setString(6, thanhvien.getEmail());
			statement.setInt(7, 1);

			status = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return status > 0 ? true : false;
	}

	@Override
	public boolean updateThanhVien(ThanhVien thanhvien) {
		// TODO Auto-generated method stub
		boolean statusExecute = false;
		String sql = "UPDATE `thanhvien` SET `tentv`=?,`diachi`=?,`maph`=?, `sodt`=?,`email`=?,`xoa`=? WHERE matv =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, thanhvien.getTentv());
			statement.setString(2, thanhvien.getDiachi());
			statement.setString(3, thanhvien.getMaph());
			statement.setString(4, thanhvien.getSodt());
			statement.setString(5, thanhvien.getEmail());
			statement.setInt(6, 1);
			statement.setString(7, thanhvien.getMatv());

			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
		
	}

	@Override
	public boolean deleteThanhVien(ThanhVien thanhvien) {
		boolean statusExecute = false;
		String sql = "UPDATE `thanhvien` SET `tentv`=?,`diachi`=?,`maph`=?, `sodt`=?,`email`=?,`xoa`=? WHERE matv =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		
		
		
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, thanhvien.getTentv());
			statement.setString(2, thanhvien.getDiachi());
			statement.setString(3, thanhvien.getMaph());
			statement.setString(4, thanhvien.getSodt());
			statement.setString(5, thanhvien.getEmail());
			statement.setInt(6, 0);
			statement.setString(7, thanhvien.getMatv());
			
			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
		
	}

	public List<XaPhuong> getAllPhuongXaByquan(String maQuanHuyen) {
		String sql = "SELECT * FROM xaphuong where maqh = ?";
		List<XaPhuong> listXaPhuong = new ArrayList<XaPhuong>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, maQuanHuyen);
			result = statement.executeQuery();

			XaPhuong xaphuong;
			while (result.next()) {
				xaphuong = new XaPhuong();
				xaphuong.setMaph(result.getString("maph"));
				xaphuong.setName(result.getString("name"));
				xaphuong.setMaqh(result.getString("maqh"));
				listXaPhuong.add(xaphuong);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listXaPhuong;
	}

	@Override
	public List<ThanhVien> getMaThanhVien(String matv) {
		String sql = "SELECT * FROM thanhvien WHERE matv = ?";
		List<ThanhVien> listThanhVien = new ArrayList<ThanhVien>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			ThanhVien thanhvien;
			while (result.next()) {
				thanhvien = new ThanhVien(result.getString("matv"), result.getString("tentv"),result.getString("diachi"),result.getString("maph"),result.getString("sodt"),result.getString("email"), result.getInt("xoa"));
				listThanhVien.add(thanhvien);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listThanhVien;
	}

	@Override
	public List<ThanhVien> getThongKe(String matp) {
		String sql = "SELECT tentv, ngaymuon, tens "
				+ "FROM tinhthanhpho JOIN quanhuyen ON tinhthanhpho.matp = quanhuyen.matp "
				+ "JOIN xaphuong ON quanhuyen.maqh = xaphuong.maqh "
				+ "JOIN thanhvien ON xaphuong.maph = thanhvien.maph "
				+ "JOIN muontra ON thanhvien.matv = muontra.matv "
				+ "JOIN chitietphieumoun ON muontra.magiaodich = chitietphieumoun.magiaodich "
				+ "JOIN sach ON chitietphieumoun.mas = sach.mas WHERE tinhthanhpho.matp =  ?";
		List<ThanhVien> listThanhVien = new ArrayList<ThanhVien>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, matp);
			result = statement.executeQuery();

			ThanhVien thanhvien;
			while (result.next()) {
				thanhvien = new ThanhVien(result.getString("tentv"),
				result.getString("ngaymuon"),
				result.getString("tens"));
				listThanhVien.add(thanhvien);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listThanhVien;
	}

	@Override
	public List<ThanhVien> getThongKeTV(String matv) {
		String sql = "SELECT tentv, ngaymuon, tens FROM thanhvien "
				+ "JOIN muontra on thanhvien.matv = muontra.matv"
				+ " JOIN chitietphieumoun ON chitietphieumoun.magiaodich = muontra.magiaodich "
				+ "JOIN sach on chitietphieumoun.mas = sach.mas WHERE thanhvien.matv  =  ?";
		List<ThanhVien> listThanhVien = new ArrayList<ThanhVien>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, matv);
			result = statement.executeQuery();

			ThanhVien thanhvien;
			while (result.next()) {
				thanhvien = new ThanhVien(result.getString("tentv"),
				result.getString("ngaymuon"),
				result.getString("tens"));
				listThanhVien.add(thanhvien);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listThanhVien;
	}

	

}
