package model.dao;

import java.util.List;
import model.bean.TheLoaiSach;

public interface ITheLoaiSachDao {
	List<TheLoaiSach> getAllTheLoaisach();

	TheLoaiSach getTacGia(String matls, String tentls);
	
	TheLoaiSach getTacGia(String tentls);

	boolean addTheLoaiSach(TheLoaiSach theloaisach);

	boolean updateTheLoaiSach(TheLoaiSach theloaisach);

	boolean deleteTheLoaiSach(TheLoaiSach theloaisach);

}
