package model.dao;
import java.util.List;
import model.bean.ThanhVien;
import model.bean.TinhThanhPho;
import model.bean.QuanHuyen;
import model.bean.XaPhuong;


public interface IThanhVienDao {
	List<TinhThanhPho> getAllTinhThanhPho();
	
	List<QuanHuyen> getAllQuanHuyen();
	
	List<XaPhuong> getAllXaPhuong();
	
	List<ThanhVien> getAllThanhVien();

	List<ThanhVien> getNameThanhVien(String tentv);
	
	List<ThanhVien> getMaThanhVien(String matv);
	
	
	ThanhVien getThanhVien(String tentv);

	boolean addThanhVien(ThanhVien thanhvien);

	boolean updateThanhVien(ThanhVien thanhvien);

	boolean deleteThanhVien(ThanhVien thanhvien);
	
	
	List<ThanhVien> getThongKe(String matp);
	List<ThanhVien> getThongKeTV(String matv);

}
