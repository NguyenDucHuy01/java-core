package model.dao;

import java.util.List;

import model.bean.Sach;

public interface ISachDao {
	List<Sach> getAllSach();
	
	List<Sach> getThongKe();

	List<Sach> getNameSach(String tens);
	
	
	List<Sach> getMaSach(String mas);

	boolean addSach(Sach sach);

	boolean updateSach(Sach sach);

	boolean deleteSach(Sach sach);

}
