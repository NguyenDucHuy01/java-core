package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.database.ConnectionUtil;
import model.bean.NhaXuatBan;

public class NhaXuatBanDao implements INhaXuatBanDao {
	private ConnectionUtil connectionUtil = new ConnectionUtil();
	
	

	@Override
	public List<NhaXuatBan> getAllNhaXuatBan() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM nhaxb";
		List<NhaXuatBan> listNhaXuatBan = new ArrayList<NhaXuatBan>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();
			NhaXuatBan nhaxuatban;
			while (result.next()) {
				nhaxuatban = new NhaXuatBan(result.getString("manxb"), result.getString("tennxb"));
				listNhaXuatBan.add(nhaxuatban);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listNhaXuatBan;
	}

	@Override
	public NhaXuatBan getNhaXuatBan(String manxb, String tennxb) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM nhaxb WHERE manxb = ? and tennxb = ?";
		List<NhaXuatBan> listNhaXuatBan = new ArrayList<NhaXuatBan>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, manxb);
			statement.setString(2, tennxb);

			result = statement.executeQuery();

			NhaXuatBan nhaxuatban;
			while (result.next()) {
				nhaxuatban = new NhaXuatBan(result.getString("manxb"), result.getString("tennxb"));
				listNhaXuatBan.add(nhaxuatban);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listNhaXuatBan.size() == 0 ? null : listNhaXuatBan.get(0);
	}

	@Override
	public NhaXuatBan getNhaXuatBan(String tennxb) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM nhaxb WHERE tennxb = ? ";
		List<NhaXuatBan> listNhaXuatBan = new ArrayList<NhaXuatBan>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(2, tennxb);
			result = statement.executeQuery();
			NhaXuatBan nhaxuatban;
			while (result.next()) {
				nhaxuatban = new NhaXuatBan(result.getString("manxb"), result.getString("tennxb"));
				listNhaXuatBan.add(nhaxuatban);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listNhaXuatBan.size() == 0 ? null : listNhaXuatBan.get(0);
	}

	@Override
	public boolean addNhaXuatBan(NhaXuatBan nhanxb) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO nhaxb VALUES(?, ?)";

		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		int status = 0;
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, nhanxb.getManxb());
			statement.setString(2, nhanxb.getTennxb());
			

			status = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return status > 0 ? true : false;
	}

	@Override
	public boolean updateNhaXuatBan(NhaXuatBan nhanxb) {
		// TODO Auto-generated method stub
		boolean statusExecute = false;
		String sql = "UPDATE `nhaxb` SET `tennxb`=? WHERE manxb =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		
		
		
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, nhanxb.getManxb());
			statement.setString(2, nhanxb.getTennxb());
			

			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
	}

	@Override
	public boolean deleteNhaXuatBan(NhaXuatBan nhanxb) {
		// TODO Auto-generated method stub
		boolean statusExecute = false;
		String sql = "UPDATE `nhaxb` SET `tentv`=? WHERE manxb =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		
		
		
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, nhanxb.getManxb());
			statement.setString(2, nhanxb.getTennxb());
			

			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
	}

}
