package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.database.ConnectionUtil;
import model.bean.TheLoaiSach;

public class TheLoaiSachDao implements ITheLoaiSachDao {
	
	private ConnectionUtil connectionUtil = new ConnectionUtil();

	@Override
	public List<TheLoaiSach> getAllTheLoaisach() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM theloaisach";
		List<TheLoaiSach> listTheLoaiSach = new ArrayList<TheLoaiSach>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			TheLoaiSach theloaisach;
			while (result.next()) {
				theloaisach = new TheLoaiSach(result.getString("matls"), result.getString("tentls"));
				listTheLoaiSach.add(theloaisach);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listTheLoaiSach;
	}

	@Override
	public TheLoaiSach getTacGia(String matls, String tentls) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM theloaisach WHERE matls = ? and tentls = ?";
		List<TheLoaiSach> listTheLoaiSach = new ArrayList<TheLoaiSach>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, matls);
			statement.setString(2, tentls);
			result = statement.executeQuery();
			TheLoaiSach theloaisach;
			while (result.next()) {
				theloaisach = new TheLoaiSach(result.getString("matls"), result.getString("tentls"));
				listTheLoaiSach.add(theloaisach);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listTheLoaiSach.size() == 0 ? null : listTheLoaiSach.get(0);
	}

	@Override
	public TheLoaiSach getTacGia(String tentls) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM theloaisach WHERE tentls = ? ";
		List<TheLoaiSach> listTheLoaiSach = new ArrayList<TheLoaiSach>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(2, tentls);
			result = statement.executeQuery();
			TheLoaiSach theloaisach;
			while (result.next()) {
				theloaisach = new TheLoaiSach(result.getString("matls"), result.getString("tentls"));
				listTheLoaiSach.add(theloaisach);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listTheLoaiSach.size() == 0 ? null : listTheLoaiSach.get(0);
	}

	@Override
	public boolean addTheLoaiSach(TheLoaiSach theloaisach) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO theloaisach VALUES(?, ?)";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		int status = 0;
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, theloaisach.getMatls());
			statement.setString(2, theloaisach.getTentls());
			status = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return status > 0 ? true : false;
	}

	@Override
	public boolean updateTheLoaiSach(TheLoaiSach theloaisach) {
		// TODO Auto-generated method stub
		boolean statusExecute = false;
		String sql = "UPDATE `theloaisach` SET `tentls`=? WHERE matls =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		
		
		
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, theloaisach.getMatls());
			statement.setString(2, theloaisach.getTentls());
			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
	}

	@Override
	public boolean deleteTheLoaiSach(TheLoaiSach theloaisach) {
		// TODO Auto-generated method stub
		return false;
	}

}
