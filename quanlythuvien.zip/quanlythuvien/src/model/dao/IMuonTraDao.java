package model.dao;

import java.util.List;

import model.bean.MuonTra;

public interface IMuonTraDao {
	List<MuonTra> getAllMuonTra();

	List<MuonTra> getMaMuonTra(String magiaodich);
	
	MuonTra getMuonTra(String magiaodich);

	boolean addMuonTra(MuonTra muontra);

	boolean updateMuonTra(MuonTra muontra);

	boolean deleteMuonTra(MuonTra muontra);

}
