package model.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.database.ConnectionUtil;
import model.bean.MuonTra;


public class MuonTraDao implements IMuonTraDao{
	private ConnectionUtil connectionUtil = new ConnectionUtil();

	@Override
	public List<MuonTra> getAllMuonTra() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM muontra";
		List<MuonTra> listMuonTra = new ArrayList<MuonTra>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			result = statement.executeQuery();

			MuonTra muontra;
			while (result.next()) {
				muontra = new MuonTra(result.getString("magiaodich"), result.getString("ngaymuon"),result.getString("ngaytra"),result.getString("matv"),result.getInt("soluong"), result.getInt("xoa"));
				listMuonTra.add(muontra);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return listMuonTra;
	}
	
	@Override
	public List<MuonTra> getMaMuonTra(String magiaodich) {
		String sql = "SELECT * FROM muontra WHERE magiaodich = ? ";
		List<MuonTra> listMuonTra = new ArrayList<MuonTra>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, magiaodich);

			result = statement.executeQuery();

			MuonTra muontra;
			while (result.next()) {
				muontra = new MuonTra(result.getString("magiaodich"), result.getString("ngaymuon"),result.getString("ngaytra"),result.getString("matv"),result.getInt("soluong"), result.getInt("xoa"));
				listMuonTra.add(muontra);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listMuonTra;
	}

	@Override
	public MuonTra getMuonTra(String magiaodich) {
		String sql = "SELECT * FROM muontra WHERE magiaodich = ? ";
		List<MuonTra> listMuonTra = new ArrayList<MuonTra>();
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;

		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, magiaodich);
			result = statement.executeQuery();
			MuonTra muontra;
			while (result.next()) {
				muontra = new MuonTra(result.getString("magiaodich"), result.getString("ngaymuon"),result.getString("ngaytra"),result.getString("matv"),result.getInt("soluong"), result.getInt("xoa"));
				listMuonTra.add(muontra);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeResultSet(result);
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}

		return listMuonTra.size() == 0 ? null : listMuonTra.get(0);
	}

	@Override
	public boolean addMuonTra(MuonTra muontra) {
		String sql = "INSERT INTO muontra VALUES(null, ?, ?, ?, ?, ?)";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		int status = 0;
		try {
			statement = connection.prepareStatement(sql);
			
			statement.setString(1, muontra.getNgaymuon());
			statement.setDate(2, Date.valueOf(muontra.getNgaytra()));
			statement.setString(3, muontra.getMatv());
			statement.setInt(4, muontra.getSoluong());
			statement.setInt(5, 1);

			status = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			connectionUtil.closeStatement(statement);
			connectionUtil.closeConnection(connection);
		}
		return status > 0 ? true : false;
	}

	@Override
	public boolean updateMuonTra(MuonTra muontra) {
		boolean statusExecute = false;
		String sql = "UPDATE `muontra` SET `ngaymuon`=?,`ngaytra`=?, `matv`=?,`soluong`=?,`xoa`=? WHERE magiaodich =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		
		
		
		try {
			statement = connection.prepareStatement(sql);
			statement.setString(1, muontra.getNgaymuon());
			statement.setString(2, muontra.getNgaytra());
			statement.setString(3, muontra.getMatv());
			statement.setInt(4, muontra.getSoluong());
			statement.setInt(5, 0);
			statement.setString(6, muontra.getMagiaodich());

			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
	}

	@Override
	public boolean deleteMuonTra(MuonTra muontra) {
		boolean statusExecute = false;
		String sql = "UPDATE `muontra` SET `ngaymuon`=?,`ngaytra`=?, `matv`=?,`soluong`=?,`xoa`=? WHERE magiaodich =?";
		Connection connection = connectionUtil.getConnection();
		PreparedStatement statement = null;
		
		
		
		try {
			statement = connection.prepareStatement(sql);
			
			statement.setString(1, muontra.getNgaymuon());
			statement.setString(2, muontra.getNgaytra());
			statement.setString(3, muontra.getMatv());
			statement.setInt(4, muontra.getSoluong());
			statement.setInt(5, 0);
			statement.setString(6, muontra.getMagiaodich());

			if (statement.executeUpdate() > 0) {
				statusExecute = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statusExecute;
	}

}
