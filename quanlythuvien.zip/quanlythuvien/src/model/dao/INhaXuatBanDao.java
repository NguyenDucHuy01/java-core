package model.dao;

import java.util.List;
import model.bean.NhaXuatBan;

public interface INhaXuatBanDao {
	List<NhaXuatBan> getAllNhaXuatBan();

	NhaXuatBan getNhaXuatBan(String manxb, String tennxb);
	
	NhaXuatBan getNhaXuatBan(String tennxb);
	

	boolean addNhaXuatBan(NhaXuatBan nhanxb);

	boolean updateNhaXuatBan(NhaXuatBan nhanxb);

	boolean deleteNhaXuatBan(NhaXuatBan nhanxb);
	

}
