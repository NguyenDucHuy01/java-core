package model.dao;

import java.util.List;

import model.bean.ChiTietMuonTra;

public interface IChiTietMuonTra {
	List<ChiTietMuonTra> getAllChiTietMuonTra();

	ChiTietMuonTra getChiTietMuonTra(String mactpm, String mas);
	
	ChiTietMuonTra getChiTietMuonTra(String mactpm);

	boolean addChiTietMuonTra(ChiTietMuonTra chiTietMuonTra);

	boolean updateChiTietMuonTra(ChiTietMuonTra chiTietMuonTra);

	boolean deleteChiTietMuonTra(ChiTietMuonTra chiTietMuonTra);
}
