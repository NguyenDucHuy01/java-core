package swing;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import javax.swing.JPasswordField;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import common.database.ConnectionUtil;

public class FormLogin extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private JLabel lbltitle;
	private JLabel lblCheckBox;
	private JLabel lblTaiKhoan;
	private JTextField txtTaiKhoan;
	private JLabel lblMatKhau;
	private JPasswordField txtMatKhau;
	private JButton btDangNhap;
	private JButton btThoat;
	private FormLogin login;
	private Statement stmt;
	private ResultSet rs;
	private Connection conn;
	private ConnectionUtil ketnoi;
	private JCheckBox hienpass;
	
	public void hienThi() {
		setTitle("QUẢN LÝ THƯ VIỆN");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(400, 250);
		add(createMainPanel());
		setLocationRelativeTo(null);
		setVisible(true);
	}
	private JPanel createMainPanel() {
		 
		JPanel panel = new JPanel(new BorderLayout(10,10));
	    panel.add(tieuDe(), BorderLayout.NORTH);
	    panel.add(canhTrai(), BorderLayout.WEST);
	    panel.add(dangNhap(), BorderLayout.CENTER);
	    panel.add(canhPhai(), BorderLayout.EAST);
	    panel.add(themButon(), BorderLayout.SOUTH);
	        
	    return panel;
	}
	private JPanel themButon() {
		// TODO Auto-generated method stub
		JPanel panel = new JPanel();
        
	    btDangNhap = new JButton();
	    btDangNhap = creatJButton("Đăng nhập");
	    btThoat = new JButton();
	    btThoat = creatJButton("Thoát");
	    panel.add(btDangNhap);
	    panel.add(btThoat);
	    
	    return panel;
	}
	private JPanel canhPhai() {
		// TODO Auto-generated method stub
		JPanel panel = new JPanel();
		JLabel lb = new JLabel("     ");
		panel.add(lb);
		return panel;
	}
	private JPanel dangNhap() {
		// TODO Auto-generated method stub
		JPanel panel = new JPanel();
		JPanel panel1 = new JPanel(new GridLayout(4, 1, 5, 5)); 
		JPanel panel12 = new JPanel();
		JPanel panel2 = new JPanel(new GridLayout(1, 2, 5, 5)); 
	    
	    lblTaiKhoan = new JLabel("Tài khoản");
	    txtTaiKhoan = new JTextField(25);
	    lblMatKhau = new JLabel("Mật khẩu");
	   
	    txtMatKhau = new JPasswordField(25);
	    lblCheckBox = new JLabel("Hiển thị mật khẩu");
	    hienpass = new JCheckBox("!");
	    hienpass.addActionListener(this);
	        
	    panel1.add(lblTaiKhoan);

	    panel1.add(txtTaiKhoan);

	    panel1.add(lblMatKhau);

	    panel1.add(txtMatKhau);
	    panel2.add(lblCheckBox);
	    panel2.add(hienpass);
	    
	    panel.add(panel1);
	    panel.add(panel12);
	    panel.add(panel2);
	    
	    return panel;
	}
	private JPanel canhTrai() {
		// TODO Auto-generated method stub
		JPanel panel = new JPanel();
		JLabel lb = new JLabel("     ");
		panel.add(lb);
	    return panel;
	}
	private JPanel tieuDe() {
		// TODO Auto-generated method stub
		JPanel panel = new JPanel();
		lbltitle = new JLabel("Đăng Nhập");  
		panel.add(lbltitle);
		return panel;
	}
	
	private JButton creatJButton(String title) {
		JButton bt = new JButton(title);
		bt.addActionListener(this);
		return bt;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btDangNhap) {
			if(txtTaiKhoan.getText().equals("") || txtMatKhau.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ tài khoản và mật khẩu");
			} else {
				ketnoi = new ConnectionUtil();
				conn = ketnoi.getConnection();
				try {
					String sql = "SELECT * FROM login WHERE usename = '"+txtTaiKhoan.getText()+"' AND password= '"+txtMatKhau.getText()+"'";
					stmt = conn.createStatement();
					rs = stmt.executeQuery(sql);
					if (rs.next()) {
						JOptionPane.showMessageDialog(null, "Đăng nhập thành công");
						//FormQuanLyThuVien qltv = new FormQuanLyThuVien();
						//qltv.ThuVien();
						
						ketnoi.closeConnection(conn);
						ketnoi.closeResultSet(rs);
						ketnoi.closeStatement(stmt);
						dispose();
					} else {
						JOptionPane.showMessageDialog(null,"Đăng nhập thất bại");
					}
				} catch (Exception ex) {
					// TODO: handle exception
					System.out.println(ex);
				}
			}
		}if(e.getSource() == btThoat) {
			int n = JOptionPane.showConfirmDialog(login, "Bạn thật sự muốn thoát ?", "Thông báo", JOptionPane.YES_NO_OPTION);
			//nếu n = 0 thì thoát chương trình ngươc lại n = 1 không thoát
			if(n!=1)
			//lệnh thoát chương trình
			System.exit(0);
		}
		if(hienpass.isSelected()) {
			lblCheckBox.setText("Ẩn mật khẩu");
			txtMatKhau.setEchoChar((char)0);
		 } else {
			lblCheckBox.setText("Hiện mật khẩu");
			txtMatKhau.setEchoChar('*');
		 }
	}
	
	public static void main(String[] args) {
		FormLogin lg = new FormLogin();
		lg.hienThi();
		}

}
