package swing;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import model.bean.NhaXuatBan;
import model.bean.Sach;
import model.bean.TacGia;
import model.bean.TheLoaiSach;
import model.dao.NhaXuatBanDao;
import model.dao.SachDao;
import model.dao.TacGiaDao;
import model.dao.TheLoaiSachDao;

public class FormQuanLySach extends JSplitPane implements ActionListener, MouseListener {

	private static final long serialVersionUID = 1L;

	SachDao sach = new SachDao();
	TacGiaDao tacGia = new TacGiaDao();
	TheLoaiSachDao theLoaiSach = new TheLoaiSachDao();
	NhaXuatBanDao nhaXuatBan = new NhaXuatBanDao();
	FormMuonTra muonTra = new FormMuonTra();

	private DefaultTableModel modelSach;
	private JButton btThemSach;
	private JButton btSuaSach;
	private JButton btXoaSach;
	private JButton btCleanSach;
	private JButton btTimKiemTenSach;
	private JTextField tens;
	private JTextField txtMaSach;
	private JTextField txtTenSach;
	private JTextField txtSoLuong;
	private JComboBox <TacGia> cbMaTacGia;
	private JComboBox <NhaXuatBan> cbMaNhaXuatBan;
	private JComboBox <TheLoaiSach> cbMaTheLoaiSach;
	private JDateChooser namXuatBan;
	private JTable tableSach;

	Font font = new Font("Arial", Font.ITALIC, 40);

	public FormQuanLySach() {
		this.setLeftComponent(leftSach());
		this.setRightComponent(rightSach());
		this.setDividerLocation(400);
	}

	private JPanel rightSach() {
		JPanel panel = new JPanel();
		JPanel timkiem = new JPanel();

		JPanel bang = new JPanel(new GridLayout(1, 1, 5, 5));

		// tìm kiếm
		JLabel lbtim = new JLabel("Tìm");
		tens = new JTextField(30);
		btTimKiemTenSach = new JButton("Tìm Kiếm");
		btTimKiemTenSach.setPreferredSize(new Dimension(100, 25));

		// add controle
		timkiem.add(lbtim);
		timkiem.add(tens);
		timkiem.add(btTimKiemTenSach);
		// bảng danh sách

		modelSach = new DefaultTableModel();
		modelSach.addColumn("Mã Sách");
		modelSach.addColumn("Tên Sách");
		modelSach.addColumn("Mã Tác Giả");
		modelSach.addColumn("Mã Nhà Xuất Bản");
		modelSach.addColumn("Năm Xuất Bản");
		modelSach.addColumn("Mã Thể Loại Sách");
		modelSach.addColumn("Số Lượng");

		tableSach = new JTable(modelSach);
		hienThiTable();
		tableSach.addMouseListener(this);
		tableSach.setPreferredSize(new Dimension(800, 2000));
		JScrollPane jpanel = new JScrollPane(tableSach);
		jpanel.setPreferredSize(new Dimension(750, 550));
		btTimKiemTenSach.addActionListener(this);
		bang.add(jpanel);

		panel.add(timkiem);
		panel.add(bang);
		return panel;
	}

	public void hienThiTable() {
		List<Sach> listSach = sach.getAllSach();
		modelSach.setRowCount(0);
		for (Sach sachItem : listSach) {
			if (sachItem.getXoa() == 1) {
				modelSach.addRow(new String[] { sachItem.getMas(), sachItem.getTens(), sachItem.getMatg(),
						sachItem.getManxb(), sachItem.getNamxb(), sachItem.getMatls(), "" + sachItem.getSoluong() });

			}
		}
	}

	private JPanel leftSach() {
		JPanel panel = new JPanel();
		JPanel thongTin = new JPanel(new GridLayout(16, 1, 5, 5));
		JPanel cot1 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot2 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot3 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot4 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot5 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot6 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot7 = new JPanel(new GridLayout(1, 2, 5, 5));

		JLabel lblSpace = new JLabel("");
		JLabel lblSpace1 = new JLabel("");
		JLabel lblSpace2 = new JLabel("");
		JLabel lblSpace3 = new JLabel("");
		JLabel lblSpace4 = new JLabel("");

		JLabel lbMaS = new JLabel("Mã Sách");
		JLabel lbTenS = new JLabel("Tên Sách");
		JLabel lbMaTG = new JLabel("Tác Giả");
		JLabel lbMaNXB = new JLabel("Nhà Xuất Bản");
		JLabel lbNamXB = new JLabel("Năm Xuất Bản");
		JLabel lbMaTLS = new JLabel("Thể loại Sách");
		JLabel lbSoLuong = new JLabel("Số Lượng");

		txtMaSach = new JTextField(15);
		txtMaSach.setEnabled(false);

		List<Sach> listSach = sach.getAllSach();
		txtMaSach.setText("" + (listSach.size() + 1));
		txtTenSach = new JTextField(15);
		txtSoLuong = new JTextField(15);

		cbMaTacGia = new JComboBox<TacGia>();
		cbMaTacGia.setPreferredSize(new Dimension(15, 30));
		cbMaNhaXuatBan = new JComboBox<NhaXuatBan>();
		cbMaNhaXuatBan.setPreferredSize(new Dimension(15, 30));
		cbMaTheLoaiSach = new JComboBox<TheLoaiSach>();
		cbMaTheLoaiSach.setPreferredSize(new Dimension(15, 30));

		List<TacGia> listTacGia = tacGia.getAllTacGia();
		cbMaTacGia.addItem(null);
		for (TacGia tacGiaiteam : listTacGia) {
			cbMaTacGia.addItem(tacGiaiteam);
		}

		List<TheLoaiSach> listtheloaisach = theLoaiSach.getAllTheLoaisach();
		cbMaTheLoaiSach.addItem(null);
		for (TheLoaiSach theloaisachiteam : listtheloaisach) {
			cbMaTheLoaiSach.addItem(theloaisachiteam);
		}

		List<NhaXuatBan> listnhaxuatban = nhaXuatBan.getAllNhaXuatBan();
		cbMaNhaXuatBan.addItem(null);
		for (NhaXuatBan nhaxuatbaniteam : listnhaxuatban) {
			cbMaNhaXuatBan.addItem(nhaxuatbaniteam);
		}

		btThemSach = new JButton("Thêm");
		btThemSach.setPreferredSize(new Dimension(15, 20));
		btSuaSach = new JButton("Sửa");
		btSuaSach.setPreferredSize(new Dimension(15, 20));
		btXoaSach = new JButton("Xóa");
		btXoaSach.setPreferredSize(new Dimension(15, 20));
		btCleanSach = new JButton("Clean");
		btCleanSach.setPreferredSize(new Dimension(15, 20));

		namXuatBan = new JDateChooser();
		namXuatBan.setPreferredSize(new Dimension(15, 30));

		cot1.add(lbMaS);
		cot1.add(txtMaSach);

		cot2.add(lbTenS);
		cot2.add(txtTenSach);

		cot3.add(lbMaTG);
		cot3.add(cbMaTacGia);

		cot4.add(lbMaNXB);
		cot4.add(cbMaNhaXuatBan);

		cot5.add(lbNamXB);
		cot5.add(namXuatBan);

		cot6.add(lbMaTLS);
		cot6.add(cbMaTheLoaiSach);

		cot7.add(lbSoLuong);
		cot7.add(txtSoLuong);

		thongTin.add(lblSpace);
		thongTin.add(lblSpace1);
		thongTin.add(lblSpace2);
		thongTin.add(cot1);
		thongTin.add(cot2);
		thongTin.add(cot3);
		thongTin.add(cot4);
		thongTin.add(cot5);
		thongTin.add(cot6);
		thongTin.add(cot7);
		thongTin.add(lblSpace3);
		thongTin.add(lblSpace4);

		thongTin.add(btThemSach);
		thongTin.add(btSuaSach);
		thongTin.add(btXoaSach);
		thongTin.add(btCleanSach);

		panel.add(thongTin);

		btCleanSach.addActionListener(this);
		btThemSach.addActionListener(this);
		btSuaSach.addActionListener(this);
		btXoaSach.addActionListener(this);

		return panel;
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		int i = tableSach.getSelectedRow();
		txtMaSach.setText(tableSach.getValueAt(i, 0).toString());
		txtMaSach.setEditable(false);
		txtTenSach.setText(tableSach.getValueAt(i, 1).toString());
		try {
			namXuatBan.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(tableSach.getValueAt(i, 4).toString()));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		List<TacGia> listTacGia = tacGia.getAllTacGia();
		for (TacGia tacGiaiteam : listTacGia) {
			if (tacGiaiteam.getMatg().equals(tableSach.getValueAt(i, 2))) {
				cbMaTacGia.getModel().setSelectedItem(tacGiaiteam);
			}
		}

		List<NhaXuatBan> listnhaxuatban = nhaXuatBan.getAllNhaXuatBan();
		for (NhaXuatBan nhaxuatbaniteam : listnhaxuatban) {
			if (nhaxuatbaniteam.getManxb().equals(tableSach.getValueAt(i, 3))) {
				cbMaNhaXuatBan.getModel().setSelectedItem(nhaxuatbaniteam);
			}
		}

		List<TheLoaiSach> listtheloaisach = theLoaiSach.getAllTheLoaisach();
		for (TheLoaiSach theloaisachiteam : listtheloaisach) {
			if (theloaisachiteam.getMatls().equals(tableSach.getValueAt(i, 5))) {
				cbMaTheLoaiSach.getModel().setSelectedItem(theloaisachiteam);
			}

		}
		txtSoLuong.setText(tableSach.getValueAt(i, 6).toString());
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btThemSach) {
			String maTacGia = ((TacGia) cbMaTacGia.getSelectedItem()).getMatg();
			String maTheLoaiSach = ((TheLoaiSach) cbMaTheLoaiSach.getSelectedItem()).getMatls();
			String maNhaXuatBan = ((NhaXuatBan) cbMaNhaXuatBan.getSelectedItem()).getManxb();

			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			Sach sach1 = new Sach(txtTenSach.getText(), maTacGia, maNhaXuatBan, df.format(namXuatBan.getDate()),
					maTheLoaiSach, Integer.parseInt(txtSoLuong.getText()), 1);

			sach.addSach(sach1);
			hienThiTable();
		}
		if (e.getSource() == btSuaSach) {
			int xoa = 1;
			String maTacGia = ((TacGia) cbMaTacGia.getSelectedItem()).getMatg();
			String maTheLoaiSach = ((TheLoaiSach) cbMaTheLoaiSach.getSelectedItem()).getMatls();
			String maNhaXuatBan = ((NhaXuatBan) cbMaNhaXuatBan.getSelectedItem()).getManxb();

			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

			Sach sach1 = new Sach(txtMaSach.getText(), txtTenSach.getText(), maTacGia, maNhaXuatBan,
					df.format(namXuatBan.getDate()), maTheLoaiSach, Integer.parseInt(txtSoLuong.getText()), xoa);
			sach.updateSach(sach1);

			hienThiTable();
		}
		if (e.getSource() == btXoaSach) {
			int xoa = 0;
			String maTacGia = ((TacGia) cbMaTacGia.getSelectedItem()).getMatg();
			String maTheLoaiSach = ((TheLoaiSach) cbMaTheLoaiSach.getSelectedItem()).getMatls();

			String maNhaXuatBan = ((NhaXuatBan) cbMaNhaXuatBan.getSelectedItem()).getManxb();
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

			Sach sach1 = new Sach(txtMaSach.getText(), txtTenSach.getText(), maTacGia, maNhaXuatBan,
					df.format(namXuatBan.getDate()), maTheLoaiSach, Integer.parseInt(txtSoLuong.getText()), xoa);
			sach.deleteSach(sach1);

			hienThiTable();
		}
		if (e.getSource() == btCleanSach) {
			List<Sach> listSach = sach.getAllSach();
			txtMaSach.setText("" + (listSach.size() + 1));
			txtTenSach.setText("");
			txtSoLuong.setText("");

		}
		if (e.getSource() == btTimKiemTenSach) {
			List<Sach> listSach = sach.getNameSach(tens.getText());
			tableSach.removeAll();
			modelSach.setRowCount(0);
			for (Sach sachItem : listSach) {
				if (sachItem.getXoa() == 1) {
					modelSach.addRow(new String[] { sachItem.getMas(), sachItem.getTens(), sachItem.getMatg(),
							sachItem.getManxb(), sachItem.getNamxb(), sachItem.getMatls(),
							"" + sachItem.getSoluong() });
				}
			}

		}
	}

	public void loadDataScreen() {

	}

}
