package swing;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class FormMain extends JFrame{

	private static final long serialVersionUID = 1L;
	private JTabbedPane myTabled;
	
	public void ThuVien() {
		setTitle("QUẢN LÝ THƯ VIỆN");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(1200, 700);
		add(createMainpanel());
		setLocationRelativeTo(null);
		setVisible(true);
	}

	private JTabbedPane createMainpanel() {
		myTabled = new JTabbedPane();

		JSplitPane qlthanhVien = new FormThanhVien();
		JSplitPane qlSach = new FormQuanLySach();
		JSplitPane qlMuon = new FormMuonTra();
		JSplitPane qlTacGia = new FormTacGia();
		JPanel thongKe = quanLyThongKe();

		myTabled.addTab("Thành Viên", qlthanhVien);
		myTabled.addTab("Quản Lý Sách", qlSach);
		myTabled.addTab("Quản Lý Mượn Sách", qlMuon);
		myTabled.addTab("Tác Giả", qlTacGia);
		myTabled.addTab("Thống Kê", thongKe);
		
		myTabled.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				int tabIndex = ((JTabbedPane)e.getSource()).getSelectedIndex();
				if (tabIndex == 1) {
					((FormQuanLySach)qlSach).loadDataScreen();
				} else if (tabIndex == 2) {
					((FormMuonTra)qlMuon).loadDataScreen();
				} else if (tabIndex == 3) {
					
				}
			}
		});
		
		return myTabled;
	}
	private JPanel quanLyThongKe() {
		// TODO Auto-generated method stub
		FormThongKe thongKe = new FormThongKe();
		

		return thongKe.khung();
	}

	
	public static void main(String[] args) {
		FormMain main = new FormMain();
		main.ThuVien();
	}

}
