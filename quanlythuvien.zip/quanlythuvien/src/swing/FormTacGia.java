package swing;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import model.bean.TacGia;
import model.dao.TacGiaDao;

public class FormTacGia extends JSplitPane implements ActionListener, MouseListener, ItemListener{
	private static final long serialVersionUID = 1L;
	private DefaultTableModel modelTacGia;
	private JTable tableTacGia;
	private JButton btThemTacGia;
	private JButton btSuaTacGia;
	private JButton btXoaTacGia;
	private JButton btCleanTacGia;
	private JButton btTimKiemTenTacGia;
	private JTextField txtTimKiemTacGia;
	private JTextField txtMaTacGia;
	private JTextField txtTenTacGia;
	
	TacGiaDao tacGia = new TacGiaDao();
	
	public FormTacGia() {
		this.setLeftComponent(leftTacGia());
		this.setRightComponent(rightTacGia());
		this.setDividerLocation(450);
	}
	private JPanel leftTacGia() {
		JPanel panel = new JPanel();
		JPanel thongTin = new JPanel(new GridLayout(11, 1, 5, 5));
		JPanel cot1 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot2 = new JPanel(new GridLayout(1, 2, 5, 5));
		JLabel lblSpace = new JLabel("");
		JLabel lblSpace1 = new JLabel("");
		JLabel lblSpace2 = new JLabel("");
		JLabel lblSpace3 = new JLabel("");
		JLabel lblSpace4 = new JLabel("");
		JLabel lbMaTG = new JLabel("Mã Tác Giả");
		JLabel lbTenTG = new JLabel("Tên Tác Giả");
		txtMaTacGia = new JTextField(18);
		txtMaTacGia.setEnabled(false);
		txtTenTacGia = new JTextField(18);
		List<TacGia>listTacGia = tacGia.getAllTacGia();
		txtMaTacGia.setText("" + (listTacGia.size()+1));
		btThemTacGia = new JButton("Thêm");
		btSuaTacGia = new JButton("Sửa");
		btXoaTacGia= new JButton("Xóa");
		btCleanTacGia= new JButton("Clean");
		
		cot1.add(lbMaTG);
		cot1.add(txtMaTacGia);
		
		cot2.add(lbTenTG);
		cot2.add(txtTenTacGia);
		
		thongTin.add(lblSpace);
		thongTin.add(lblSpace1);
		thongTin.add(lblSpace2);
		thongTin.add(cot1);
		thongTin.add(cot2);
		thongTin.add(lblSpace3);
		thongTin.add(lblSpace4);
		thongTin.add(btThemTacGia);
		thongTin.add(btSuaTacGia);
		thongTin.add(btXoaTacGia);
		thongTin.add(btCleanTacGia);
		btThemTacGia.addActionListener(this);
		btSuaTacGia.addActionListener(this);
		btXoaTacGia.addActionListener(this);
		btCleanTacGia.addActionListener(this);
		panel.add(thongTin);
		return panel;
	}
	
	private JPanel rightTacGia() {
		JPanel panel1 = new JPanel();
		JPanel timkiem = new JPanel();
		JPanel bang = new JPanel(new GridLayout(1, 1, 5, 5));
		// tìm kiếm
		JLabel lbtim = new JLabel("Tìm");
		txtTimKiemTacGia = new JTextField(30);
		btTimKiemTenTacGia = new JButton("Tìm Kiếm");
		btTimKiemTenTacGia.setPreferredSize(new Dimension(100, 25));
		
		timkiem.add(lbtim);
		timkiem.add(txtTimKiemTacGia);
		timkiem.add(btTimKiemTenTacGia);
		
		btTimKiemTenTacGia.addActionListener(this);
		
		modelTacGia = new DefaultTableModel();
		modelTacGia.addColumn("Mã Tác Giả");
		modelTacGia.addColumn("Tên Tác Giả");
		
		tableTacGia = new JTable(modelTacGia);
		hienThiTable();
		tableTacGia.addMouseListener(this);
		tableTacGia.setPreferredSize(new Dimension(900, 2000));
		JScrollPane jpanel = new JScrollPane(tableTacGia);
		jpanel.setPreferredSize(new Dimension(680, 550));
		bang.add(jpanel);
		
		panel1.add(timkiem);
		panel1.add(bang);
		return panel1;
	}
	private void hienThiTable() {
		List<TacGia>listTacGia = tacGia.getAllTacGia();
		modelTacGia.setRowCount(0);
		for(TacGia tacGiaIteam : listTacGia) {
			modelTacGia.addRow(new String[] {tacGiaIteam.getMatg(),tacGiaIteam.getTentg()});
		}
	}
	@Override
	public void itemStateChanged(ItemEvent arg0) {
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		int i = tableTacGia.getSelectedRow();
		txtMaTacGia.setText(tableTacGia.getValueAt(i, 0).toString());
		txtTenTacGia.setText(tableTacGia.getValueAt(i, 1).toString());
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btThemTacGia) {
			TacGia tacGia1 = new TacGia(txtMaTacGia.getText(), txtTenTacGia.getText());
			tacGia.addTacGia(tacGia1);
			hienThiTable();
		}
		if (e.getSource() == btSuaTacGia) {
			TacGia tacGia1 = new TacGia(txtMaTacGia.getText(),txtTenTacGia.getText());
			tacGia.updateTacGia(tacGia1);
			hienThiTable();
		}
		if (e.getSource() == btXoaTacGia) {
			TacGia tacGia1 = new TacGia(txtMaTacGia.getText(),txtTenTacGia.getText());
			tacGia.deleteTacGia(tacGia1);
			hienThiTable();
	
		}
		if (e.getSource() == btCleanTacGia) {
			txtTenTacGia.setText("");
		}
		if (e.getSource() == btTimKiemTenTacGia) {
			List<TacGia>listTacGia = tacGia.getNameTacGia(txtTimKiemTacGia.getText());
			tableTacGia.removeAll();
			modelTacGia.setRowCount(0);
			for(TacGia tacGiaIteam : listTacGia) {
				modelTacGia.addRow(new String[] {tacGiaIteam.getMatg(),tacGiaIteam.getTentg()});
			}
			
		}
	}
	

}
