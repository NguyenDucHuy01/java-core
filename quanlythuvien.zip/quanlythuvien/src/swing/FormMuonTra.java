package swing;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.util.StringUtils;
import com.toedter.calendar.JDateChooser;

import model.bean.ChiTietMuonTra;
import model.bean.MuonTra;
import model.bean.Sach;
import model.bean.ThanhVien;
import model.dao.ChiTietMuonTraDao;
import model.dao.MuonTraDao;
import model.dao.SachDao;
import model.dao.ThanhVienDao;

public class FormMuonTra extends JSplitPane implements ActionListener, MouseListener, ItemListener {

	private static final long serialVersionUID = 1L;

	MuonTraDao muonTra = new MuonTraDao();
	ThanhVienDao thanhVien = new ThanhVienDao();
	SachDao sach = new SachDao();
	ChiTietMuonTraDao chiTietMuonTra = new ChiTietMuonTraDao();
	private int count;
	private JLabel lbNgayMuon1;

	private DefaultTableModel model;

	private JButton btThemMS;
	private JButton btSuaMS;
	private JButton btXoaMS;
	private JButton btCleanMS;
	private JButton btTraS;
	private JButton btTimKiemMaGD;
	private JTextField txtTimKiem;
	private JTextField txtMaMuonTra;

	private JComboBox<ThanhVien> cbMaTV;
	private JComboBox<Sach> cbMaS;
	private JComboBox<Sach> cbMaS1;
	private JComboBox<Sach> cbMaS2;
	private JTable tableDanhSach;

	private JDateChooser ngayTra;
	private JDateChooser TKNgayTra;

	Font font = new Font("Arial", Font.ITALIC, 40);

	public FormMuonTra() {
		this.setLeftComponent(leftMuon());
		this.setRightComponent(rightMuon());
		this.setDividerLocation(470);
	}

	private JPanel rightMuon() {

		JPanel panel = new JPanel();
		JPanel timkiem = new JPanel(new GridLayout(1, 4, 5, 5));
		JPanel bang = new JPanel(new GridLayout(1, 1, 5, 5));

		// tìm kiếm
		JLabel lbtim = new JLabel("Tìm");
		txtTimKiem = new JTextField(15);
		TKNgayTra = new JDateChooser();
		TKNgayTra.setPreferredSize(new Dimension(15, 30));
		btTimKiemMaGD = new JButton("Tìm Kiếm");
		btTimKiemMaGD.setPreferredSize(new Dimension(25, 25));
		btTimKiemMaGD.addActionListener(this);
		timkiem.add(lbtim);
		timkiem.add(TKNgayTra);
		timkiem.add(txtTimKiem);
		timkiem.add(btTimKiemMaGD);
		// bảng danh sách

		model = new DefaultTableModel();
		model.addColumn("Mã Gia Dịch");
		model.addColumn("Ngày Mượn");
		model.addColumn("Ngày Trã");
		model.addColumn("Mã Thành Viên");
		//model.addColumn("Số Lượng");

		tableDanhSach = new JTable(model);

		tableDanhSach.setPreferredSize(new Dimension(670, 2000));
		JScrollPane jpanel = new JScrollPane(tableDanhSach);
		jpanel.setPreferredSize(new Dimension(670, 550));

		tableDanhSach.addMouseListener(this);
		btTimKiemMaGD.addActionListener(this);
		bang.add(jpanel);
		hienThiBang();
		panel.add(timkiem);
		panel.add(bang);
		return panel;
	}

	private void hienThiBang() {
		List<MuonTra> listMuontra = muonTra.getAllMuonTra();
		model.setRowCount(0);
		for (MuonTra muontraiteam : listMuontra) {
			if(muontraiteam.getXoa() == 1) {
				model.addRow(new String[] { muontraiteam.getMagiaodich(), muontraiteam.getNgaymuon(),
						muontraiteam.getNgaytra(), muontraiteam.getMatv(), "" + muontraiteam.getSoluong() });
				count = muontraiteam.getSoluong();
			}
			

		}
	}

	private String ngayHeThong() {
		long millis = System.currentTimeMillis();

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date(millis);
		String dateFormat = formatter.format(date);
		return dateFormat;
	}

	private JPanel leftMuon() {

		JPanel panel = new JPanel();
		JPanel thongTin = new JPanel(new GridLayout(16, 1, 5, 5));

		JPanel cot0 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot1 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot2 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot3 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot4 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot5 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot6 = new JPanel(new GridLayout(1, 2, 5, 5));

		JLabel lbMaTV = new JLabel("Mã Thành Viên");
		JLabel lbMaGiaoDich = new JLabel("Mã Giao Dich");
		txtMaMuonTra = new JTextField(20);
		txtMaMuonTra.setEditable(false);

		List<MuonTra> listmuontra = muonTra.getAllMuonTra();
		txtMaMuonTra.setText("" + (listmuontra.size() + 1));
		JLabel lbTenS = new JLabel("Tên Sách");
		JLabel lbNgayMuon = new JLabel("Ngày Mượn");
		JLabel lbNgayTra = new JLabel("Ngày Trả");

		lbNgayMuon1 = new JLabel("                     " + ngayHeThong() + "                     ");

		JLabel lblSpace = new JLabel("");
		JLabel lblSpace1 = new JLabel("");
		JLabel lblSpace2 = new JLabel("");
		JLabel lblSpace3 = new JLabel("");
		JLabel lblSpace4 = new JLabel("");
		JLabel lblSpace5 = new JLabel("");
		JLabel lblSpace6 = new JLabel("");

		cbMaTV = new JComboBox<ThanhVien>();

		cbMaTV.setPreferredSize(new Dimension(40, 30));
		cbMaS = new JComboBox<Sach>();
		cbMaS.setPreferredSize(new Dimension(40, 30));
		cbMaS1 = new JComboBox<Sach>();
		cbMaS1.setPreferredSize(new Dimension(40, 30));
		cbMaS2 = new JComboBox<Sach>();
		cbMaS2.setPreferredSize(new Dimension(40, 30));

		hienThiComboBoxThanhVien();

		hienThiCBSach1();

		hienThiCBSach2();

		hienThiCBSach3();
		ngayTra = new JDateChooser();
		ngayTra.setPreferredSize(new Dimension(20, 30));

		btThemMS = new JButton("Thêm");
		btThemMS.setPreferredSize(new Dimension(20, 20));
		btSuaMS = new JButton("Sửa");
		btSuaMS.setPreferredSize(new Dimension(20, 20));
		btXoaMS = new JButton("Xóa");
		btXoaMS.setPreferredSize(new Dimension(20, 20));
		btCleanMS = new JButton("Clean");
		btCleanMS.setPreferredSize(new Dimension(20, 20));
		btTraS = new JButton("Trả Sách");
		btTraS.setPreferredSize(new Dimension(20, 20));

		cot0.add(lbMaGiaoDich);
		cot0.add(txtMaMuonTra);

		cot1.add(lbMaTV);
		cot1.add(cbMaTV);

		cot2.add(lbTenS);
		cot2.add(cbMaS);

		cot3.add(lblSpace);
		cot3.add(cbMaS1);

		cot4.add(lblSpace1);
		cot4.add(cbMaS2);

		cot5.add(lbNgayMuon);
		cot5.add(lbNgayMuon1);

		cot6.add(lbNgayTra);
		cot6.add(ngayTra);

		thongTin.add(lblSpace2);
		thongTin.add(lblSpace3);
		thongTin.add(lblSpace4);
		thongTin.add(cot0);
		thongTin.add(cot1);
		thongTin.add(cot2);
		thongTin.add(cot3);
		thongTin.add(cot4);
		thongTin.add(cot5);
		thongTin.add(cot6);
		thongTin.add(lblSpace5);
		thongTin.add(lblSpace6);
		thongTin.add(btThemMS);
		thongTin.add(btSuaMS);
		// thongTin.add(btXoaMS);
		thongTin.add(btTraS);
		thongTin.add(btCleanMS);

		btThemMS.addActionListener(this);
		btSuaMS.addActionListener(this);
		// btXoaMS.addActionListener(this);
		btTraS.addActionListener(this);
		btCleanMS.addActionListener(this);

		cbMaS.addItemListener(this);
		cbMaS1.addItemListener(this);
		cbMaS2.addItemListener(this);

		panel.add(thongTin);

		return panel;
	}

//	private boolean kiemTra() {
//		int soLuong = 0;
//		List<ChiTietMuonTra>listChiTiet = chiTietMuonTra.getAllChiTietMuonTra();
//		for(ChiTietMuonTra chiTietMT : listChiTiet) {
////			if(chiTietMT.getMas() ) {
////				
////			}
//		}
		
//
//		return true;
//	}

	public void removeCBTV() {

	}

	public void hienThiComboBoxThanhVien() {
		List<ThanhVien> listThanhVien = thanhVien.getAllThanhVien();
		cbMaTV.removeAll();
		cbMaTV.addItem(null);
		for (ThanhVien thanhVienIteam : listThanhVien) {
			cbMaTV.addItem(thanhVienIteam);
		}
	}

	public void hienThiCBSach1() {
		List<Sach> listSach = sach.getAllSach();
		cbMaS.removeAllItems();
		cbMaS.addItem(null);
		for (Sach sachIteam : listSach) {
			cbMaS.addItem(sachIteam);
		}
	}

	public void hienThiCBSach2() {
		List<Sach> listSach1 = sach.getAllSach();
		cbMaS1.removeAllItems();
		cbMaS1.addItem(null);
		for (Sach sachIteam : listSach1) {
			cbMaS1.addItem(sachIteam);
		}
	}

	public void hienThiCBSach3() {
		List<Sach> listSach2 = sach.getAllSach();
		cbMaS2.removeAllItems();
		cbMaS2.addItem(null);
		for (Sach sachIteam : listSach2) {
			cbMaS2.addItem(sachIteam);
		}
	}

	private void muonSach1() {
		sach = new SachDao();
		String maSach = ((Sach) cbMaS.getSelectedItem()).getMas();
		List<Sach> listSach = sach.getMaSach(maSach);
		for (Sach quyenSach : listSach) {
			Sach qSach = new Sach(maSach, quyenSach.getTens(), quyenSach.getMatg(), quyenSach.getManxb(),
					quyenSach.getNamxb(), quyenSach.getMatls(), quyenSach.getSoluong() - 1, 1);
			sach.updateSach1(qSach);
		}
	}

	private void muonSach2() {
		sach = new SachDao();
		String maSach = ((Sach) cbMaS1.getSelectedItem()).getMas();
		List<Sach> listSach = sach.getMaSach(maSach);
		for (Sach quyenSach : listSach) {
			Sach qSach = new Sach(maSach, quyenSach.getTens(), quyenSach.getMatg(), quyenSach.getManxb(),
					quyenSach.getNamxb(), quyenSach.getMatls(), quyenSach.getSoluong() - 1, 1);
			sach.updateSach1(qSach);
		}
	}

	private void muonSach3() {
		sach = new SachDao();
		String maSach = ((Sach) cbMaS2.getSelectedItem()).getMas();
		List<Sach> listSach = sach.getMaSach(maSach);
		for (Sach quyenSach : listSach) {
			Sach qSach = new Sach(maSach, quyenSach.getTens(), quyenSach.getMatg(), quyenSach.getManxb(),
					quyenSach.getNamxb(), quyenSach.getMatls(), quyenSach.getSoluong() - 1, 1);
			sach.updateSach1(qSach);
		}
	}
	private void traSach() {
		sach = new SachDao();
		String maSach = ((Sach) cbMaS.getSelectedItem()).getMas();
		List<Sach> listSach = sach.getMaSach(maSach);
		for (Sach quyenSach : listSach) {
			Sach qSach = new Sach(maSach, quyenSach.getTens(), quyenSach.getMatg(), quyenSach.getManxb(),
					quyenSach.getNamxb(), quyenSach.getMatls(), quyenSach.getSoluong() + 1, 1);
			sach.updateSach1(qSach);
		}
	}
	private void traSach1() {
		sach = new SachDao();
		String maSach = ((Sach) cbMaS1.getSelectedItem()).getMas();
		List<Sach> listSach = sach.getMaSach(maSach);
		for (Sach quyenSach : listSach) {
			Sach qSach = new Sach(maSach, quyenSach.getTens(), quyenSach.getMatg(), quyenSach.getManxb(),
					quyenSach.getNamxb(), quyenSach.getMatls(), quyenSach.getSoluong() + 1, 1);
			sach.updateSach1(qSach);
		}
	}
	private void traSach2() {
		sach = new SachDao();
		String maSach = ((Sach) cbMaS2.getSelectedItem()).getMas();
		List<Sach> listSach = sach.getMaSach(maSach);
		for (Sach quyenSach : listSach) {
			Sach qSach = new Sach(maSach, quyenSach.getTens(), quyenSach.getMatg(), quyenSach.getManxb(),
					quyenSach.getNamxb(), quyenSach.getMatls(), quyenSach.getSoluong() + 1, 1);
			sach.updateSach1(qSach);
		}
	}
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == btThemMS) {
			String maSach = ((Sach) cbMaS.getSelectedItem()).getMas();
			String maSach1 = ((Sach) cbMaS1.getSelectedItem()).getMas();
			String maSach2 = ((Sach) cbMaS2.getSelectedItem()).getMas();
			String maThanhVien = ((ThanhVien) cbMaTV.getSelectedItem()).getMatv();
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			MuonTra muonTra1 = new MuonTra(ngayHeThong(), df.format(ngayTra.getDate()), maThanhVien, 3, 1);
			ChiTietMuonTra chiTietMuonTra1 = new ChiTietMuonTra(maSach, txtMaMuonTra.getText());
			ChiTietMuonTra chiTietMuonTra2 = new ChiTietMuonTra(maSach1, txtMaMuonTra.getText());
			ChiTietMuonTra chiTietMuonTra3 = new ChiTietMuonTra(maSach2, txtMaMuonTra.getText());
			muonTra.addMuonTra(muonTra1);
			
			chiTietMuonTra.addChiTietMuonTra(chiTietMuonTra1);
			muonSach1();
			chiTietMuonTra.addChiTietMuonTra(chiTietMuonTra2);
			muonSach2();
			chiTietMuonTra.addChiTietMuonTra(chiTietMuonTra3);
			muonSach3();
			hienThiBang();
		}
		if (e.getSource() == btSuaMS) {
			if (e.getSource() == btTraS) {
				List<MuonTra> listMuonTra = muonTra.getMaMuonTra(txtMaMuonTra.getText());
				int delete = 0;
				for(MuonTra muonTraSach : listMuonTra) {
					MuonTra muon_Tra = new MuonTra(txtMaMuonTra.getText(),
							muonTraSach.getNgaymuon(),
							muonTraSach.getNgaytra(),
							muonTraSach.getMatv(),
							muonTraSach.getSoluong(),
							delete);
					muonTra.updateMuonTra(muon_Tra);
				}
				hienThiBang();
//			String maSach = ((Sach) cbMaS.getSelectedItem()).getMas();
//			String maSach1 = ((Sach) cbMaS1.getSelectedItem()).getMas();
//			String maSach2 = ((Sach) cbMaS2.getSelectedItem()).getMas();
//			String maThanhVien = ((ThanhVien) cbMaTV.getSelectedItem()).getMatv();
//			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
//			MuonTra muonTra1 = new MuonTra(ngayHeThong(), df.format(ngayTra.getDate()), maThanhVien, 3, 1);
//			ChiTietMuonTra chiTietMuonTra1 = new ChiTietMuonTra(maSach, txtMaMuonTra.getText());
//			ChiTietMuonTra chiTietMuonTra2 = new ChiTietMuonTra(maSach1, txtMaMuonTra.getText());
//			ChiTietMuonTra chiTietMuonTra3 = new ChiTietMuonTra(maSach2, txtMaMuonTra.getText());
//			muonTra.addMuonTra(muonTra1);
//			chiTietMuonTra.updateChiTietMuonTra(chiTietMuonTra1);
//			muonSach1();
//			chiTietMuonTra.updateChiTietMuonTra(chiTietMuonTra2);
//			muonSach2();
//			chiTietMuonTra.updateChiTietMuonTra(chiTietMuonTra3);
//			muonSach3();
//			hienThiBang();
		}
		}
		if (e.getSource() == btTraS) {
			List<MuonTra> listMuonTra = muonTra.getMaMuonTra(txtMaMuonTra.getText());
			int delete = 0;
			for(MuonTra muonTraSach : listMuonTra) {
				MuonTra muon_Tra = new MuonTra(txtMaMuonTra.getText(),
						muonTraSach.getNgaymuon(),
						muonTraSach.getNgaytra(),
						muonTraSach.getMatv(),
						muonTraSach.getSoluong(),
						delete);
				muonTra.deleteMuonTra(muon_Tra);
			}
			hienThiBang();
		}
		if (e.getSource() == btCleanMS) {
			List<MuonTra> listmuontra = muonTra.getAllMuonTra();
			txtMaMuonTra.setText("" + (listmuontra.size() + 1));
			cbMaTV.removeAllItems();
			hienThiComboBoxThanhVien();

		}

		if (e.getSource() == btTimKiemMaGD) {
			List<MuonTra> listmuontra = muonTra.getMaMuonTra(txtTimKiem.getText());
			tableDanhSach.removeAll();
			model.setRowCount(0);
			for (MuonTra muontraiteam : listmuontra) {
				model.addRow(new String[] { muontraiteam.getMagiaodich(), muontraiteam.getNgaymuon(),
						muontraiteam.getNgaytra(), muontraiteam.getMatv(), "" + muontraiteam.getSoluong() });
			}
		}
	}


	@Override
	public void mouseClicked(MouseEvent arg0) {
		int i = tableDanhSach.getSelectedRow();
		txtMaMuonTra.setText(tableDanhSach.getValueAt(i, 0).toString());
		List<Sach> listTenSach =  sach.getTenSachByMaMuonTra(txtMaMuonTra.getText());
		System.out.println( listTenSach);
		lbNgayMuon1.setText(tableDanhSach.getValueAt(i, 1).toString());
		try {
			ngayTra.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(tableDanhSach.getValueAt(i, 2).toString()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		List<ThanhVien> listThanhVien = thanhVien.getAllThanhVien();
		for (ThanhVien thanhVienIteam : listThanhVien) {
			if (thanhVienIteam.getMatv().equals(tableDanhSach.getValueAt(i, 3))) {
				cbMaTV.getModel().setSelectedItem(thanhVienIteam);
			}
		}
		
		listTenSach.add(null);
		listTenSach.add(null);
		Sach[] sach1 = new Sach[listTenSach.size()];
		sach1 = listTenSach.toArray(sach1);
		for (int i1 = 0; i1 < listTenSach.size(); i1++) {
            sach1[i1] = listTenSach.get(i1);
        }
			cbMaS.getModel().setSelectedItem( sach1[0]);
			cbMaS1.getModel().setSelectedItem(sach1[1]);
			cbMaS2.getModel().setSelectedItem(sach1[2]);
		List<MuonTra> listMuonTra = muonTra.getAllMuonTra();
		List<ChiTietMuonTra> listChiTietMuonTra = chiTietMuonTra.getAllChiTietMuonTra();
		List<Sach> listSach = sach.getAllSach();
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
//			if (e.getSource() == cbMaS) {
//
//				int soLuong = ((Sach) cbMaS.getSelectedItem()).getSoluong();
//				if (soLuong <= 1) {
//					JOptionPane.showMessageDialog(this, "Số lượng Sách không đủ để cho mượn");
//					hienThiCBSach1();
//				} 
//			}
//
//				int soLuong = ((Sach) cbMaS1.getSelectedItem()).getSoluong();
//				if (soLuong <= 1) {
//					JOptionPane.showMessageDialog(this, "Số lượng Sách không đủ để cho mượn");
//					hienThiCBSach2();
//				} 
//			}
//			if (e.getSource() == cbMaS2) {
//				int soLuong = ((Sach) cbMaS2.getSelectedItem()).getSoluong();
//				if (soLuong <= 1) {
//					JOptionPane.showMessageDialog(this, "Số lượng Sách không đủ để cho mượn");
//					hienThiCBSach3();
//				} 
//			}
		}
	}

	public void loadDataScreen() {
		hienThiCBSach1();
		hienThiCBSach2();
		hienThiCBSach3();
		hienThiComboBoxThanhVien();
	}

}
