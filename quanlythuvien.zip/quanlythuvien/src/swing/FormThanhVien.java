package swing;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import model.bean.QuanHuyen;
import model.bean.ThanhVien;
import model.bean.TinhThanhPho;
import model.bean.XaPhuong;
import model.dao.ThanhVienDao;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class FormThanhVien extends JSplitPane implements ActionListener, MouseListener, ItemListener {

	private static final long serialVersionUID = 1L;

	private DefaultTableModel modelThanhVien;

	private JButton btThemThanhVien;
	private JButton btSuaThanhVien;
	private JButton btXoaThanhVien;
	private JButton btCleanThanhVien;
	private JButton btTimKiemMaThanhVien;
	private JTextField txtTimKiemThanhVien;
	private JTextField txtMaThanhVien;
	private JTextField txtTenThanhVien;
	private JTextField txtDiaChi;
	private JTextField txtSoDienThoai;
	private JTextField txtEmail;

	private JComboBox<XaPhuong> cbMaPhuong;
	private JComboBox<TinhThanhPho> cbMaThanhPho;
	private JComboBox<QuanHuyen> cbQuan;
	private JTable tableThanhVien;

	ThanhVienDao xaPhuong = new ThanhVienDao();
	ThanhVienDao quanHuyen = new ThanhVienDao();
	ThanhVienDao thanhPho = new ThanhVienDao();
	ThanhVienDao thanhVien = new ThanhVienDao();

	

	public FormThanhVien() {
		this.setLeftComponent(leftThanhVien());
		this.setRightComponent(rightThanhVien());
		this.setDividerLocation(470);
		
	}

	private JPanel leftThanhVien() {

		JPanel panel = new JPanel();

		JPanel thongTin = new JPanel(new GridLayout(17, 1, 5, 5));
		JPanel cot1 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot2 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot3 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot4 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot5 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot6 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot7 = new JPanel(new GridLayout(1, 2, 5, 5));
		JPanel cot8 = new JPanel(new GridLayout(1, 2, 5, 5));

		JLabel lblSpace = new JLabel("");
		JLabel lblSpace1 = new JLabel("");
		JLabel lblSpace2 = new JLabel("");
		JLabel lblSpace3 = new JLabel("");
		JLabel lblSpace4 = new JLabel("");

		JLabel lbMaTV = new JLabel("Mã Thành Viên");
		JLabel lbTenTV = new JLabel("Tên Thành Viên");
		JLabel lbDiaChi = new JLabel("Địa Chỉ");
		JLabel lbMaThanhPho = new JLabel("Thành Phố");
		JLabel lbMaQuan = new JLabel("Quận Huyện");
		JLabel lbMaPhuong = new JLabel("Phường Xã");
		JLabel lbSodt = new JLabel("Số Điện Thoại");
		JLabel lbEmail = new JLabel("Email");
		txtMaThanhVien = new JTextField(20);
		txtMaThanhVien.setEnabled(false);

		List<ThanhVien> listThanhvien = thanhVien.getAllThanhVien();
		txtMaThanhVien.setText(""+(listThanhvien.size() + 1));

		txtTenThanhVien = new JTextField(20);
		txtDiaChi = new JTextField(20);
		txtSoDienThoai = new JTextField(20);
		txtEmail = new JTextField(20);
		cbMaPhuong = new JComboBox<XaPhuong>();
		cbMaPhuong.setPreferredSize(new Dimension(20, 30));
		cbQuan = new JComboBox<QuanHuyen>();
		cbQuan.setPreferredSize(new Dimension(20, 30));
		cbMaThanhPho = new JComboBox<TinhThanhPho>();
		cbMaThanhPho.setPreferredSize(new Dimension(20, 30));

		List<XaPhuong> listXaPhuong = xaPhuong.getAllXaPhuong();
		loadDataforPhuong(listXaPhuong);

		List<QuanHuyen> listQuanHuyen = quanHuyen.getAllQuanHuyen();
		loadDataforQuan(listQuanHuyen);

		cbMaThanhPho.removeAllItems();
		List<TinhThanhPho> listTinhThanhPho = thanhPho.getAllTinhThanhPho();
		cbMaThanhPho.addItem(null);
		for (TinhThanhPho thanhphoiteam : listTinhThanhPho) {
			cbMaThanhPho.addItem(thanhphoiteam);
		}

		btThemThanhVien = new JButton("Thêm");
		btThemThanhVien.setPreferredSize(new Dimension(20, 20));
		btSuaThanhVien = new JButton("Sửa");
		btSuaThanhVien.setPreferredSize(new Dimension(20, 20));
		btXoaThanhVien = new JButton("Xóa");
		btXoaThanhVien.setPreferredSize(new Dimension(20, 20));
		btCleanThanhVien = new JButton("Clean");
		btCleanThanhVien.setPreferredSize(new Dimension(20, 20));

		cot1.add(lbMaTV);
		cot1.add(txtMaThanhVien);

		cot2.add(lbTenTV);
		cot2.add(txtTenThanhVien);

		cot3.add(lbDiaChi);
		cot3.add(txtDiaChi);

		cot4.add(lbMaPhuong);
		cot4.add(cbMaPhuong);

		cot5.add(lbSodt);
		cot5.add(txtSoDienThoai);

		cot6.add(lbEmail);
		cot6.add(txtEmail);

		cot7.add(lbMaQuan);
		cot7.add(cbQuan);

		cot8.add(lbMaThanhPho);
		cot8.add(cbMaThanhPho);

		thongTin.add(lblSpace);
		thongTin.add(lblSpace1);
		thongTin.add(lblSpace2);
		thongTin.add(cot1);
		thongTin.add(cot2);
		thongTin.add(cot3);
		thongTin.add(cot8);
		thongTin.add(cot7);
		thongTin.add(cot4);
		thongTin.add(cot5);
		thongTin.add(cot6);
		thongTin.add(lblSpace3);
		thongTin.add(lblSpace4);
		thongTin.add(btThemThanhVien);
		thongTin.add(btSuaThanhVien);
		thongTin.add(btXoaThanhVien);
		thongTin.add(btCleanThanhVien);
		panel.add(thongTin);

		// add su kien cho button
		btCleanThanhVien.addActionListener(this);
		btThemThanhVien.addActionListener(this);
		btSuaThanhVien.addActionListener(this);
		btXoaThanhVien.addActionListener(this);

		// them su kien cho thanh pho quan phuong
		cbMaThanhPho.addItemListener(this);
		cbQuan.addItemListener(this);

		return panel;
	}

	private JPanel rightThanhVien() {

		JPanel panel = new JPanel();
		JPanel timkiem = new JPanel();
		JPanel bang = new JPanel(new GridLayout(1, 1, 5, 5));

		// tìm kiếm
		JLabel lbtim = new JLabel("Tìm");
		txtTimKiemThanhVien = new JTextField(30);
		btTimKiemMaThanhVien = new JButton("Tìm Kiếm");
		btTimKiemMaThanhVien.setPreferredSize(new Dimension(100, 25));
		// add controle
		timkiem.add(lbtim);
		timkiem.add(txtTimKiemThanhVien);
		timkiem.add(btTimKiemMaThanhVien);

		btTimKiemMaThanhVien.addActionListener(this);
		// bảng danh sách

		modelThanhVien = new DefaultTableModel();
		modelThanhVien.addColumn("Mã Thành Viên");
		modelThanhVien.addColumn("Tên Thành Viên");
		modelThanhVien.addColumn("Địa Chỉ");
		modelThanhVien.addColumn("Tên Phường");
		modelThanhVien.addColumn("Số Điện Thoại");
		modelThanhVien.addColumn("Email");

		tableThanhVien = new JTable(modelThanhVien);
		hienThiTable();
		tableThanhVien.addMouseListener(this);
		tableThanhVien.setPreferredSize(new Dimension(900, 2000));
		JScrollPane jpanel = new JScrollPane(tableThanhVien);
		jpanel.setPreferredSize(new Dimension(680, 550));
		bang.add(jpanel);

		panel.add(timkiem);
		panel.add(bang);

		return panel;
	}

	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == btThemThanhVien) {
			int xoa = 1;
			String maPhuong = ((XaPhuong) cbMaPhuong.getSelectedItem()).getMaph();
			ThanhVien thanhVien1 = new ThanhVien(txtTenThanhVien.getText(), txtDiaChi.getText(), maPhuong,
					txtSoDienThoai.getText(), txtEmail.getText(), xoa);
			thanhVien.addThanhVien(thanhVien1);
			hienThiTable();

		}
		if (e.getSource() == btSuaThanhVien) {
			int xoa = 1;
			String maPhuong = ((XaPhuong) cbMaPhuong.getSelectedItem()).getMaph();
			ThanhVien thanhvien = new ThanhVien(txtMaThanhVien.getText(), txtTenThanhVien.getText(),
					txtDiaChi.getText(), maPhuong, txtSoDienThoai.getText(), txtEmail.getText(), xoa);
			
			thanhVien.updateThanhVien(thanhvien);
			hienThiTable();
		}
		if (e.getSource() == btXoaThanhVien) {
			int xoa = 0;
			String maPhuong = ((XaPhuong) cbMaPhuong.getSelectedItem()).getMaph();
			ThanhVien thanhvien = new ThanhVien(txtMaThanhVien.getText(), txtTenThanhVien.getText(),
					txtDiaChi.getText(), maPhuong, txtSoDienThoai.getText(), txtEmail.getText(), xoa);
			
			thanhVien.deleteThanhVien(thanhvien);
			hienThiTable();

		}
		if (e.getSource() == btCleanThanhVien) {
			ThanhVienDao thanhvien = new ThanhVienDao();
			List<ThanhVien> listThanhvien = thanhvien.getAllThanhVien();
			txtMaThanhVien.setText("" + listThanhvien.size() + 1);
			txtTenThanhVien.setText("");
			txtDiaChi.setText("");
			txtSoDienThoai.setText("");
			txtEmail.setText("");

		}
		if (e.getSource() == btTimKiemMaThanhVien) {
			List<ThanhVien> listThanhVien = thanhVien.getNameThanhVien(txtTimKiemThanhVien.getText());
			tableThanhVien.removeAll();
			modelThanhVien.setRowCount(0);
			for (ThanhVien thanhvieniteam : listThanhVien) {
				if (thanhvieniteam.getXoa() == 1) {

					modelThanhVien.addRow(
							new String[] { thanhvieniteam.getMatv(), thanhvieniteam.getTentv(), thanhvieniteam.getDiachi(),
									thanhvieniteam.getMaph(), thanhvieniteam.getSodt(), thanhvieniteam.getEmail() });
				}
			}
		}
	}



	@Override
	public void mouseClicked(MouseEvent arg0) {
		
		int i = tableThanhVien.getSelectedRow();
		txtMaThanhVien.setText(tableThanhVien.getValueAt(i, 0).toString());
		txtMaThanhVien.setEditable(false);
		txtTenThanhVien.setText(tableThanhVien.getValueAt(i, 1).toString());
		txtDiaChi.setText(tableThanhVien.getValueAt(i, 2).toString());

		List<XaPhuong> listXaPhuong = xaPhuong.getAllXaPhuong();
		for (XaPhuong xaphuongiteam : listXaPhuong) {
			if (xaphuongiteam.getMaph().equals(tableThanhVien.getValueAt(i, 3))) {
				cbMaPhuong.getModel().setSelectedItem(xaphuongiteam);
			}
		}
		txtSoDienThoai.setText(tableThanhVien.getValueAt(i, 4).toString());
		txtEmail.setText(tableThanhVien.getValueAt(i, 5).toString());
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
			if (e.getSource() == cbMaThanhPho) {
				String maThanhPho = ((TinhThanhPho) cbMaThanhPho.getSelectedItem()).getMatp();
				cbQuan.removeAllItems();
				loadDataforQuan(quanHuyen.getAllQuanHuyenByThanhPho(maThanhPho));
			} else {
				String maQuanHuyen = ((QuanHuyen) cbQuan.getSelectedItem()).getMaqh();
				cbMaPhuong.removeAllItems();
				loadDataforPhuong(quanHuyen.getAllPhuongXaByquan(maQuanHuyen));
			}
		}
	}

	private void loadDataforQuan(List<QuanHuyen> quanHuyenList) {
		cbQuan.addItem(null);
		for (QuanHuyen quanhuyeniteam : quanHuyenList) {
			cbQuan.addItem(quanhuyeniteam);
		}
	}
	
	private void loadDataforPhuong(List<XaPhuong> listXaPhuong) {
		cbMaPhuong.addItem(null);
		for (XaPhuong xaphuongiteam : listXaPhuong) {
			cbMaPhuong.addItem(xaphuongiteam);

		}
	}
	private void hienThiTable() {
		List<ThanhVien> listThanhVien = thanhVien.getAllThanhVien();
//		List<XaPhuong> listXaPhuong = xaPhuong.getAllXaPhuong();
		modelThanhVien.setRowCount(0);
		for (ThanhVien thanhvieniteam : listThanhVien) {	
//			String maPhuong = ((XaPhuong) cbMaPhuong.getSelectedItem()).getMaph();
//			String tenPhuong = ((XaPhuong) thanhvieniteam.getMaph()).getName();
			if (thanhvieniteam.getXoa() == 1) {
				modelThanhVien.addRow(
						new String[] { thanhvieniteam.getMatv(), thanhvieniteam.getTentv(), thanhvieniteam.getDiachi(),
							thanhvieniteam.getMaph(),thanhvieniteam.getSodt(), thanhvieniteam.getEmail() });
			}
		}
	}
}
